$(document).ready(function () {
    setupLectorTab();
    setupWiFiTab();
    setupNTPConfTab();
    setupMqttTab();
    setupWebAuthTab();
    setupYuboxOTATab();

    // Mostrar el tab preparado por omisión como activo
    $('ul#yuboxMainTab a.set-active').removeClass('set-active').tab('show');
});

function setupLectorTab()
{
    var lectorpane = getYuboxPane('lector');
    var data = {
        'sse':  null,
        'chart': null,
    };
    lectorpane.data(data);

    var ctx = lectorpane.find('canvas#atmospheric')[0].getContext('2d');
    var chtData = {
        datasets:   [{
            label:  'Presión',
            borderColor: "rgb(255, 99, 132)",
            backgroundColor: "rgb(255, 99, 132)",
            fill: false,
            data: [],
            yAxisID: 'press'
        },{
            label:  'Temperatura',
            borderColor: "rgb(54, 162, 235)",
            backgroundColor: "rgb(54, 162, 235)",
            fill: false,
            data: [],
            yAxisID: 'temp'
        }]
    };
    var cht = new Chart(ctx, {
        type:       'line',
        data:       chtData,
        options:    {
            responsive: true,
            hoverMode: 'index',
            stacked: false,
            title: {
                display: true,
                text: 'Presión y temperatura'
            },
            scales: {
                xAxes:  [{
                    type:   'time'
                }],
                yAxes:  [{
                    type: 'linear',
                    display: true,
                    position: 'left',
                    id: 'press'
                },{
                    type: 'linear',
                    display: true,
                    position: 'right',
                    id: 'temp'
                }]
            }
        }
    });
    lectorpane.data('chart', cht);

    if (!!window.EventSource) {
        var sse = new EventSource(yuboxAPI('lectura')+'/events');
        sse.addEventListener('message', function (e) {
            var data = $.parseJSON(e.data);
            yuboxLector_actualizar(new Date(data.ts), data.pressure, data.temperature);
        });
        lectorpane.data('sse', sse);
    }
}

function yuboxLector_actualizar(d, p, t)
{
    var lectorpane = getYuboxPane('lector');
    lectorpane.find('h3#temp').text(t.toFixed(2));
    lectorpane.find('h3#press').text(p.toFixed(2));
    var cht = lectorpane.data('chart');
    cht.data.datasets[0].data.push({x: d, y: p});
    cht.data.datasets[1].data.push({x: d, y: t});
    if (d.valueOf() - cht.data.datasets[0].data[0].x.valueOf() > 10 * 60 * 1000) {
        cht.data.datasets[0].data.shift();
        cht.data.datasets[1].data.shift();
    }
    cht.update();
}


function setupWiFiTab()
{
    var wifipane = getYuboxPane('wifi');
    var data = {
        'sse': null,
        'wifiscan-template':
            wifipane.find('table#wifiscan > tbody > tr.template')
            .removeClass('template')
            .detach(),
        'wifinetworks-template':
            wifipane.find('div#wifi-networks table#wifi-saved-networks > tbody > tr.template')
            .removeClass('template')
            .detach()
    }
    wifipane.data(data);

    // https://getbootstrap.com/docs/4.4/components/navs/#events
    getYuboxNavTab('wifi')
    .on('shown.bs.tab', function (e) {
        yuboxWiFi_setupWiFiScanListener();
    })
    .on('hide.bs.tab', function (e) {
        var wifipane = getYuboxPane('wifi');
        if (wifipane.data('sse') != null) {
          wifipane.data('sse').close();
          wifipane.data('sse', null);
        }
    });

    // Qué hay que hacer al hacer clic en una fila que representa la red
    wifipane.find('table#wifiscan > tbody').on('click', 'tr', function(e) {
        var wifipane = getYuboxPane('wifi');
        var net = $(e.currentTarget).data();

        if (net.connected) {
            $.getJSON(yuboxAPI('wificonfig')+'/connection')
            .done(function (data) {
                var dlg_wifiinfo = wifipane.find('div#wifi-details');

                var res = evaluarIntensidadRedWifi(dlg_wifiinfo.find('tr#rssi > td > svg.wifipower'), data.rssi);
                dlg_wifiinfo.find('tr#rssi > td.text-muted').text(res.diag + ' ('+res.pwr+' %)');

                dlg_wifiinfo.find('tr#auth > td > svg.wifiauth > path').hide();
                dlg_wifiinfo.find('tr#auth > td > svg.wifiauth > path.'+(net.authmode != 0 ? 'locked' : 'unlocked')).show();
                dlg_wifiinfo.find('tr#auth > td.text-muted').text(wifiauth_desc(net.authmode));

                dlg_wifiinfo.find('tr#bssid > td.text-muted').text(net.ap[0].bssid);
                dlg_wifiinfo.find('tr#channel > td.text-muted').text(net.ap[0].channel);

                dlg_wifiinfo.find('h5#wifi-details-title').text(data.ssid);
                dlg_wifiinfo.find('input#ssid').val(data.ssid);
                dlg_wifiinfo.find('div#netinfo div#mac').text(data.mac);
                dlg_wifiinfo.find('div#netinfo div#ipv4').text(data.ipv4);
                dlg_wifiinfo.find('div#netinfo div#gateway').text(data.gateway);
                dlg_wifiinfo.find('div#netinfo div#netmask').text(data.netmask);

                var div_dns = dlg_wifiinfo.find('div#netinfo div#dns');
                div_dns.empty();
                for (var i = 0; i < data.dns.length; i++) {
                    var c = $('<div class="col"/>').text(data.dns[i]);
                    var r = $('<div class="row" />');
                    r.append(c);
                    div_dns.append(r);
                }

                dlg_wifiinfo.modal({ focus: true });
            })
            .fail(function (e) { yuboxStdAjaxFailHandler(e, 2000); });
        } else {
            var dlg_wificred = wifipane.find('div#wifi-credentials');

            // Preparar diálogo para red escaneada
            dlg_wificred.find('div.modal-body').removeClass('manual').addClass('scanned');

            dlg_wificred.find('h5#wifi-credentials-title').text(net.ssid);
            dlg_wificred.find('input#ssid').val(net.ssid);
            dlg_wificred.find('input#key_mgmt').val(wifiauth_desc(net.authmode));
            dlg_wificred.find('input#authmode').val(net.authmode);
            dlg_wificred.find('input#bssid').val(net.ap[0].bssid);
            dlg_wificred.find('input#channel').val(net.ap[0].channel);
            dlg_wificred.find('input[name="pin"]#N').click();

            var sel_authmode = dlg_wificred.find('select#authmode');
            if (net.authmode == 5) {
                // Autenticación WPA-ENTERPRISE
                dlg_wificred.find('div.form-group.wifi-auth-eap input#identity')
                    .val((net.identity != null) ? net.identity : '');
                dlg_wificred.find('div.form-group.wifi-auth-eap input#password')
                    .val((net.password != null) ? net.password : '');
                sel_authmode.val(5);
            } else if (net.authmode > 0) {
                // Autenticación con contraseña
                dlg_wificred.find('div.form-group.wifi-auth-psk input#psk')
                    .val((net.psk != null) ? net.psk : '');
                sel_authmode.val(4);
            } else {
                // Red sin autenticación
                sel_authmode.val(0);
            }
            sel_authmode.change();
            dlg_wificred.find('div.modal-footer button[name=connect]').text('Conectar a WIFI');
            dlg_wificred.modal({ focus: true });
        }
    });
    wifipane.find('div#wifi-credentials select#authmode').change(function () {
        var dlg_wificred = wifipane.find('div#wifi-credentials');
        var authmode = $(this).val();

        dlg_wificred.find('div.form-group.wifi-auth').hide();
        dlg_wificred.find('div.form-group.wifi-auth input').val('');
        dlg_wificred.find('button[name=connect]').prop('disabled', true);
        if (authmode == 5) {
            // Autenticación WPA-ENTERPRISE
            dlg_wificred.find('div.form-group.wifi-auth-eap').show();
            dlg_wificred.find('div.form-group.wifi-auth-eap input#password')
                .change();
        } else if (authmode > 0) {
            // Autenticación con contraseña
            dlg_wificred.find('div.form-group.wifi-auth-psk').show();
            dlg_wificred.find('div.form-group.wifi-auth-psk input#psk')
                .change();
        } else {
            // Red sin autenticación, activar directamente opción de conectar
            dlg_wificred.find('button[name=connect]').prop('disabled', false);
        }
    });

    // Qué hay que hacer al hacer clic en el botón de Redes Guardadas
    wifipane.find('button[name=networks]').click(function () {
        $.getJSON(yuboxAPI('wificonfig')+'/networks')
        .done(function (data) {
            var wifipane = getYuboxPane('wifi');
            var dlg_wifinetworks = wifipane.find('div#wifi-networks');
            var tbody_wifinetworks = dlg_wifinetworks.find('table#wifi-saved-networks > tbody');
            tbody_wifinetworks.empty();

            data.forEach(function (net) {
                var tr_wifinet = wifipane.data('wifinetworks-template').clone();
                tr_wifinet.data('ssid', net.ssid);
                tr_wifinet.children('td#ssid').text(net.ssid);
                if (net.identity != null) {
                    // Autenticación WPA-ENTERPRISE
                    tr_wifinet.children('td#auth').attr('title', 'Seguridad: ' + wifiauth_desc(5));
                    tr_wifinet.find('td#auth > svg.wifiauth > path.locked').show();
                } else if (net.psk != null) {
                    // Autenticación PSK
                    tr_wifinet.children('td#auth').attr('title', 'Seguridad: ' + wifiauth_desc(4));
                    tr_wifinet.find('td#auth > svg.wifiauth > path.locked').show();
                } else {
                    // Sin autenticación
                    tr_wifinet.children('td#auth').attr('title', 'Seguridad: ' + wifiauth_desc(0));
                    tr_wifinet.find('td#auth > svg.wifiauth > path.unlocked').show();
                }
                tbody_wifinetworks.append(tr_wifinet);
            });

            dlg_wifinetworks.modal({ focus: true });
        })
        .fail(function (e) { yuboxStdAjaxFailHandler(e, 2000); });
    });

    // Qué hay que hacer al hacer clic en el botón de Agregar red .
    // NOTA: hay 2 botones que se llaman igual. Uno en la interfaz principal, y el otro
    // en el diálogo de mostrar las redes guardadas. El comportamiento a continuación
    // define la acción para AMBOS botones.
    wifipane.find('button[name=addnet]').click(function () {
        var dlg_wificred = wifipane.find('div#wifi-credentials');

        // Preparar diálogo para red manual
        dlg_wificred.find('div.modal-body').removeClass('scanned').addClass('manual');

        dlg_wificred.find('h5#wifi-credentials-title').text('Agregar red');
        dlg_wificred.find('input#ssid').val('');
        dlg_wificred.find('input[name="pin"]#N').click();

        dlg_wificred.find('select#authmode').val(4);
        dlg_wificred.find('select#authmode').change();

        dlg_wificred.find('div.modal-footer button[name=connect]').text('Guardar');

        var dlg_wifinetworks = wifipane.find('div#wifi-networks');
        if (dlg_wifinetworks.is(':visible')) {
            dlg_wifinetworks.modal('hide');
        }
        dlg_wificred.modal({ focus: true });
    });

    wifipane.find('div#wifi-networks table#wifi-saved-networks > tbody').on('click', 'tr td#delete button.btn-danger', function (e) {
        var wifipane = getYuboxPane('wifi');
        var dlg_wifinetworks = wifipane.find('div#wifi-networks');
        var tr_wifinet = $(e.currentTarget).parents('tr').first();
        var ssid = tr_wifinet.data('ssid');

        if (!confirm("Presione OK para OLVIDAR las credenciales de la red "+ssid)) return;

        var st = {
            method: 'DELETE',
            url:    yuboxAPI('wificonfig')+'/networks/'+ssid
        };
        $.ajax(st)
        .done(function (data) {
            // Credenciales borradas
            tr_wifinet.detach();
        })
        .fail(function (e) {
            yuboxStdAjaxFailHandlerDlg(dlg_wifinetworks.find('div.modal-body'), e, 2000);
        });
    });

    // Comportamiento de controles de diálogo de ingresar credenciales red
    var dlg_wificred = wifipane.find('div#wifi-credentials');
    dlg_wificred.find('div.form-group.wifi-auth-eap input')
        .change(checkValidWifiCred_EAP)
        .keypress(checkValidWifiCred_EAP)
        .blur(checkValidWifiCred_EAP);
    dlg_wificred.find('div.form-group.wifi-auth-psk input')
        .change(checkValidWifiCred_PSK)
        .keypress(checkValidWifiCred_PSK)
        .blur(checkValidWifiCred_PSK);
    dlg_wificred.find('div.modal-footer button[name=connect]').click(function () {
        var wifipane = getYuboxPane('wifi');
        var dlg_wificred = wifipane.find('div#wifi-credentials');
        var st;
        if (dlg_wificred.find('div.modal-body').hasClass('scanned')) {
            st = {
                url:    yuboxAPI('wificonfig')+'/connection',
                method: 'PUT',
                data:   {
                    ssid:       dlg_wificred.find('input#ssid').val(),
                    authmode:   parseInt(dlg_wificred.find('input#authmode').val()),
                    pin:        (dlg_wificred.find('input[name="pin"]:checked').val() == '1') ? 1 : 0
                }
            };
        } else if (dlg_wificred.find('div.modal-body').hasClass('manual')) {
            st = {
                url:    yuboxAPI('wificonfig')+'/networks',
                method: 'POST',
                data:   {
                    ssid:       dlg_wificred.find('input#ssid').val(),
                    authmode:   parseInt(dlg_wificred.find('select#authmode').val())
                }
            };
        }
        if ( st.data.authmode == 5 ) {
            // Autenticación WPA-ENTERPRISE
            st.data.identity = dlg_wificred.find('div.form-group.wifi-auth-eap input#identity').val();
            st.data.password = dlg_wificred.find('div.form-group.wifi-auth-eap input#password').val();
        } else if ( st.data.authmode > 0 ) {
            // Autenticación PSK
            st.data.psk = dlg_wificred.find('div.form-group.wifi-auth-psk input#psk').val();
        }

        if (dlg_wificred.find('div.modal-body').hasClass('scanned')) {
            // Puede ocurrir que la red ya no exista según el escaneo más reciente
            var existe = (
                wifipane.find('table#wifiscan > tbody > tr')
                .filter(function() { return ($(this).data('ssid') == st.data.ssid);  })
                .length > 0);
            if (!existe) {
                dlg_wificred.modal('hide');
                yuboxMostrarAlertText('warning', 'La red '+st.data.ssid+' ya no se encuentra disponible', 3000);
                return;
            }
        }

        // La red todavía existe en el último escaneo. Se intenta conectar.
        $.ajax(st)
        .done(function (data) {
            // Credenciales aceptadas, se espera a que se conecte
            if (dlg_wificred.find('div.modal-body').hasClass('scanned')) {
                marcarRedDesconectandose();
            }
            dlg_wificred.modal('hide');
        })
        .fail(function (e) {
            yuboxStdAjaxFailHandlerDlg(dlg_wificred.find('div.modal-body'), e, 2000);
        });
    });

    // Comportamiento de controles de diálogo de mostrar estado de red conectada
    var dlg_wifiinfo = wifipane.find('div#wifi-details');
    dlg_wifiinfo.find('div.modal-footer button[name=forget]').click(function () {
        var wifipane = getYuboxPane('wifi');
        var dlg_wifiinfo = wifipane.find('div#wifi-details');
        var st = {
            url:    yuboxAPI('wificonfig')+'/connection',
            method: 'DELETE'
        };

        $.ajax(st)
        .done(function (data) {
            // Credenciales aceptadas, se espera a que se conecte
            marcarRedDesconectandose();
            dlg_wifiinfo.modal('hide');
        })
        .fail(function (e) {
            yuboxStdAjaxFailHandlerDlg(dlg_wifiinfo.find('div.modal-body'), e, 2000);
        });
    });
}

function checkValidWifiCred_EAP()
{
    // Activar el botón de enviar credenciales si ambos valores son no-vacíos
    var wifipane = getYuboxPane('wifi');
    var dlg_wificred = wifipane.find('div#wifi-credentials');
    var numLlenos = dlg_wificred
        .find('div.form-group.wifi-auth-eap input')
        .filter(function() { return ($(this).val() != ''); })
        .length;
    dlg_wificred.find('button[name=connect]').prop('disabled', !(numLlenos >= 2));
}

function checkValidWifiCred_PSK()
{
    // Activar el botón de enviar credenciales si la clave es de al menos 8 caracteres
    var wifipane = getYuboxPane('wifi');
    var dlg_wificred = wifipane.find('div#wifi-credentials');
    var psk = dlg_wificred.find('div.form-group.wifi-auth-psk input#psk').val();
    dlg_wificred.find('button[name=connect]').prop('disabled', !(psk.length >= 8));
}

function yuboxWiFi_setupWiFiScanListener()
{
    if (!getYuboxNavTab('wifi').hasClass('active')) {
        // El tab de WIFI ya no está visible, no se hace nada
        return;
    }

    var wifipane = getYuboxPane('wifi');
    if (!!window.EventSource) {
        var sse = new EventSource(yuboxAPI('wificonfig')+'/netscan');
        sse.addEventListener('WiFiScanResult', function (e) {
          var data = $.parseJSON(e.data);
          yuboxWiFi_actualizarRedes(data);
        });
        sse.addEventListener('WiFiStatus', function (e) {
            var data = $.parseJSON(e.data);
            if (!data.yubox_control_wifi) {
              yuboxMostrarAlertText('warning',
                'YUBOX Now ha cedido control del WiFi a otra librería. El escaneo WiFi podría no refrescarse, o mostrar datos desactualizados.',
                5000);
            }
        });
        sse.addEventListener('error', function (e) {
          mostrarReintentoScanWifi('Se ha perdido conexión con dispositivo para siguiente escaneo');
        });
        wifipane.data('sse', sse);
    } else {
        yuboxMostrarAlertText('danger', 'Este navegador no soporta Server-Sent Events, no se puede escanear WiFi.');
    }
}

function yuboxWiFi_actualizarRedes(data)
{
    var wifipane = getYuboxPane('wifi');

    data.sort(function (a, b) {
        if (a.connected || a.connfail) return -1;
        if (b.connected || b.connfail) return 1;
        return b.rssi - a.rssi;
    });

    var tbody_wifiscan = wifipane.find('table#wifiscan > tbody');
    tbody_wifiscan.empty();
    var dlg_wifiinfo = wifipane.find('div#wifi-details');
    var ssid_visible = null;
    if (dlg_wifiinfo.is(':visible')) {
        ssid_visible = dlg_wifiinfo.find('input#ssid').val();
    }
    var max_rssi = null;
    data.forEach(function (net) {
        // Buscar en la lista existente la fila de quien tenga el SSID indicado.
        var tr_wifiscan;
        var f = tbody_wifiscan.children('tr').filter(function(idx) { return ($(this).data('ssid') == net.ssid); });
        if (f.length > 0) {
            // Se encontró SSID duplicado. Se asume que primero aparece el más potente
            tr_wifiscan = $(f[0]);
        } else {
            // Primera vez que aparece SSID en lista
            tr_wifiscan = wifipane.data('wifiscan-template').clone();
            for (var k in net) {
                if (['bssid', 'channel', 'rssi'].indexOf(k) == -1) tr_wifiscan.data(k, net[k]);
            }
            tr_wifiscan.data('ap', []);
            tbody_wifiscan.append(tr_wifiscan);
        }
        delete f;
        tr_wifiscan.data('ap').push({
            bssid:      net.bssid,
            channel:    net.channel,
            rssi:       net.rssi
        });
        var wifidata = tr_wifiscan.data();

        // Mostrar dibujo de intensidad de señal a partir de RSSI
        var res = evaluarIntensidadRedWifi(tr_wifiscan.find('td#rssi > svg.wifipower'), wifidata.ap[0].rssi);
        tr_wifiscan.children('td#rssi').attr('title', 'Intensidad de señal: '+res.pwr+' %');

        // Verificar si se está mostrando la red activa en el diálogo
        if (ssid_visible != null && ssid_visible == wifidata.ssid) {
            if (max_rssi == null || max_rssi < wifidata.ap[0].rssi) max_rssi = wifidata.ap[0].rssi;
        }

        // Mostrar estado de conexión y si hay credenciales guardadas
        tr_wifiscan.children('td#ssid').text(wifidata.ssid);
        if (wifidata.connected) {
            var sm_connlabel = $('<small class="form-text text-muted" />').text('Conectado');
            tr_wifiscan.addClass('table-success');
            tr_wifiscan.children('td#ssid').append(sm_connlabel);
        } else if (wifidata.connfail) {
            var sm_connlabel = $('<small class="form-text text-muted" />').text('Ha fallado la conexión');
            tr_wifiscan.addClass('table-danger');
            tr_wifiscan.children('td#ssid').append(sm_connlabel);
        } else if (wifidata.saved) {
            // Si hay credenciales guardadas se muestra que existen
            var sm_connlabel = $('<small class="form-text text-muted" />').text('Guardada');
            tr_wifiscan.children('td#ssid').append(sm_connlabel);
        }

        // Mostrar candado según si hay o no autenticación para la red
        tr_wifiscan.children('td#auth').attr('title',
            'Seguridad: ' + wifiauth_desc(wifidata.authmode));
        tr_wifiscan.find('td#auth > svg.wifiauth > path.'+(wifidata.authmode != 0 ? 'locked' : 'unlocked')).show();

        tr_wifiscan.data(wifidata);
    });

    // Verificar si se está mostrando la red activa en el diálogo
    if (ssid_visible != null && max_rssi != null) {
        var res = evaluarIntensidadRedWifi(dlg_wifiinfo.find('tr#rssi > td > svg.wifipower'), max_rssi);
        dlg_wifiinfo.find('tr#rssi > td.text-muted').text(res.diag + ' ('+res.pwr+' %)');
    }
}

function evaluarIntensidadRedWifi(svg_wifi, rssi)
{
    var diagnostico;
    var pwr = rssi2signalpercent(rssi);
    svg_wifi.removeClass('at-least-1bar at-least-2bars at-least-3bars at-least-4bars');
    if (pwr >= 80) {
        svg_wifi.addClass('at-least-4bars');
        diagnostico = 'Excelente';
    } else if (pwr >= 60) {
        svg_wifi.addClass('at-least-3bars');
        diagnostico = 'Buena';
    } else if (pwr >= 40) {
        svg_wifi.addClass('at-least-2bars');
        diagnostico = 'Regular';
    } else if (pwr >= 20) {
        svg_wifi.addClass('at-least-1bar');
        diagnostico = 'Débil';
    } else {
        diagnostico = 'Nula';
    }

    return { pwr: pwr, diag: diagnostico };
}

function mostrarReintentoScanWifi(msg)
{
    if (!getYuboxNavTab('wifi').hasClass('active')) {
        // El tab de WIFI ya no está visible, no se hace nada
        return;
    }

    var btn = $('<button class="btn btn-primary float-right" />').text('Reintentar');
    var al = yuboxMostrarAlert('danger',
        $('<div class="clearfix"/>')
        .append($('<span class="float-left" />').text(msg))
        .append(btn));
    btn.click(function () {
        al.remove();
        yuboxWiFi_setupWiFiScanListener();
    });
}

function wifiauth_desc(authmode)
{
    var desc_authmode = [
        '(ninguna)',
        'WEP',
        'WPA-PSK',
        'WPA2-PSK',
        'WPA-WPA2-PSK',
        'WPA2-ENTERPRISE'
    ];

    return (authmode >= 0 && authmode < desc_authmode.length)
        ? desc_authmode[authmode]
        : '(desconocida)';
}

function rssi2signalpercent(rssi)
{
    // El YUBOX ha reportado hasta ahora valores de RSSI de entre -100 hasta 0.
    // Se usa esto para calcular el porcentaje de fuerza de señal
    if (rssi > 0) rssi = 0;
    if (rssi < -100) rssi = -100;
    return rssi + 100;
}

function marcarRedDesconectandose(ssid)
{
    var wifipane = getYuboxPane('wifi');
    var tr_connected = wifipane.find('table#wifiscan > tbody > tr.table-success');
    if (tr_connected.length <= 0) return;
    if (ssid != null && tr_connected.data('ssid') != ssid) return;

    tr_connected.removeClass('table-success').addClass('table-warning');
    tr_connected.find('td#ssid > small.text-muted').text('Desconectándose');
}

function setupNTPConfTab()
{
    var ntppane = getYuboxPane('ntpconfig');

    // Llenar los select con valores para elegir zona horaria
    var sel_tzh = ntppane.find('select#ntptz_hh');
    var sel_tzm = ntppane.find('select#ntptz_mm');
    for (var i = -12; i <= 14; i++) {
        $('<option></option>')
            .val(i)
            .text(((i >= 0) ? '+' : '-')+(("0"+Math.abs(i)).slice(-2)))
            .appendTo(sel_tzh);
    }
    for (var i = 0; i < 60; i++) {
        $('<option></option>')
            .val(i)
            .text(("0"+Math.abs(i)).slice(-2))
            .appendTo(sel_tzm);
    }
    ntppane.find('button[name=apply]').click(function () {
        var ntppane = getYuboxPane('ntpconfig');
        var sel_tzh = ntppane.find('select#ntptz_hh');
        var sel_tzm = ntppane.find('select#ntptz_mm');
    
        var postData = {
            ntphost:    ntppane.find('form input#ntphost').val(),
            ntptz:      parseInt(sel_tzh.val()) * 3600
        };
        postData.ntptz += ((postData.ntptz >= 0) ? 1 : -1) * parseInt(sel_tzm.val()) * 60;

        $.post(yuboxAPI('ntpconfig')+'/conf.json', postData)
        .done(function (r) {
            if (r.success) {
                // Recargar los datos recién guardados del dispositivo
                yuboxMostrarAlertText('success', r.msg, 3000);

                // Recargar luego de 5 segundos para verificar que la conexión
                // realmente se puede realizar.
                setTimeout(yuboxLoadNTPConfig, 5 * 1000);
            } else {
                yuboxMostrarAlertText('danger', r.msg);
            }
        })
        .fail(function (e) { yuboxStdAjaxFailHandler(e, 2000); });
    });

    // https://getbootstrap.com/docs/4.4/components/navs/#events
    getYuboxNavTab('ntpconfig')
    .on('shown.bs.tab', function (e) {
        yuboxLoadNTPConfig();
    });
}

function yuboxLoadNTPConfig()
{
    var ntppane = getYuboxPane('ntpconfig');
    ntppane.find('form span#ntp_connstatus')
        .removeClass('badge-success badge-danger')
        .addClass('badge-secondary')
        .text('(consultando)');
    ntppane.find('form span#ntp_timestamp').text('...');

    $.get(yuboxAPI('ntpconfig')+'/conf.json')
    .done(function (data) {
        var sel_tzh = ntppane.find('select#ntptz_hh');
        var sel_tzm = ntppane.find('select#ntptz_mm');
        var span_connstatus = ntppane.find('form span#ntp_connstatus');
        var span_timestamp = ntppane.find('form span#ntp_timestamp');

        span_connstatus.removeClass('badge-danger badge-success badge-secondary');
        span_timestamp.text('');
        if (data.ntpsync) {
            span_connstatus
                .addClass('badge-success')
                .text('SINCRONIZADO');
            //span_timestamp.text('TODO');
        } else {
            span_connstatus
                .addClass('badge-danger')
                .text('NO SINCRONIZADO');
            span_timestamp.text('No se ha contactado a servidor NTP');
        }

        ntppane.find('form input#ntphost').val(data.ntphost);
        sel_tzh.val(Math.trunc(data.ntptz / 3600));
        sel_tzm.val(Math.trunc(Math.abs((data.ntptz % 3600) / 60)));
    })
    .fail(function (e) {
        ntppane.find('form span#ntp_connstatus')
            .removeClass('badge-success badge-danger badge-secondary')
            .addClass('badge-danger')
            .text('NO SINCRONIZADO');
        ntppane.find('form span#ntp_timestamp').text('(error en consulta)');

        yuboxStdAjaxFailHandler(e, 2000);
    });
}
function setupMqttTab()
{
    var mqttpane = getYuboxPane('mqtt');

    mqttpane.find('input[name=mqttauth]').click(function() {
        var mqttpane = getYuboxPane('mqtt');

        var nstat = mqttpane.find('input[name=mqttauth]:checked').val();
        if (nstat == 'on') {
            mqttpane.find('form div.mqttauth').show();
            mqttpane.find('form div.mqttauth input').prop('required', true);
        } else {
            mqttpane.find('form div.mqttauth').hide();
            mqttpane.find('form div.mqttauth input').prop('required', false);
        }
    });
    mqttpane.find('button[name=apply]').click(function () {
        var mqttpane = getYuboxPane('mqtt');

        var postData = {
            host:           mqttpane.find('input#mqtthost').val(),
            port:           mqttpane.find('input#mqttport').val(),
            tls_verifylevel:mqttpane.find('input[name=tls_verifylevel]:checked').val(),
            user:           null,
            pass:           null
        };
        if (mqttpane.find('input[name=mqttauth]:checked').val() == 'on') {
            postData.user = mqttpane.find('input#mqttuser').val();
            postData.pass = mqttpane.find('input#mqttpass').val();
        }
        $.post(yuboxAPI('mqtt')+'/conf.json', postData)
        .done(function (r) {
            if (r.success) {
                // Recargar los datos recién guardados del dispositivo
                yuboxMostrarAlertText('success', r.msg, 3000);

                // Recargar luego de 5 segundos para verificar que la conexión
                // realmente se puede realizar.
                setTimeout(yuboxLoadMqttConfig, 5 * 1000);
            } else {
                yuboxMostrarAlertText('danger', r.msg);
            }
        })
        .fail(function (e) { yuboxStdAjaxFailHandler(e, 2000); });
    });
    mqttpane.find('input[type=file].custom-file-input').change(function () {
        var lbl = $(this).next('label.custom-file-label');
        if (lbl.data('default') == undefined) {
            // Almacenar texto original para restaurar si archivo vacío
            lbl.data('default', lbl.text())
        }
        var txt = ($(this)[0].files.length > 0)
            ? $(this)[0].files[0].name
            : lbl.data('default');
        lbl.text(txt);
    });
    mqttpane.find('button[name=tls_servercert_upload]').click(function() {
        yuboxUploadMQTTCerts(yuboxAPI('mqtt')+'/tls_servercert', ['tls_servercert']);
    });
    mqttpane.find('button[name=tls_clientcert_upload]').click(function() {
        yuboxUploadMQTTCerts(yuboxAPI('mqtt')+'/tls_clientcert', ['tls_clientcert', 'tls_clientkey']);
    });

    // https://getbootstrap.com/docs/4.4/components/navs/#events
    getYuboxNavTab('mqtt')
    .on('shown.bs.tab', function (e) {
        yuboxLoadMqttConfig();
    });
}

function yuboxLoadMqttConfig()
{
    var mqttpane = getYuboxPane('mqtt');
    mqttpane.find('form span#mqtt_connstatus')
        .removeClass('badge-success badge-danger')
        .addClass('badge-secondary')
        .text('(consultando)');
    mqttpane.find('form span#mqtt_disconnected_reason').text('...');

    $.get(yuboxAPI('mqtt')+'/conf.json')
    .done(function (data) {
        mqttpane.find('form span#mqtt_clientid').text(data.clientid);
        var span_tls_capable = mqttpane.find('form span#tls_capable');
        span_tls_capable.removeClass('badge-success badge-secondary');
        if (data.tls_capable) {
            span_tls_capable.addClass('badge-success').text('PRESENTE');
        } else {
            span_tls_capable.addClass('badge-secondary').text('AUSENTE');
        }

        var span_connstatus = mqttpane.find('form span#mqtt_connstatus');
        var span_reason = mqttpane.find('form span#mqtt_disconnected_reason');
        span_connstatus.removeClass('badge-danger badge-success badge-secondary');
        span_reason.text('');
        if (!data.want2connect) {
            span_connstatus.addClass('badge-secondary').text('NO REQUERIDO');
        } else if (data.connected) {
            span_connstatus.addClass('badge-success').text('CONECTADO');
        } else {
            var reason = '???';
            span_connstatus.addClass('badge-danger').text('DESCONECTADO');
            switch (data.disconnected_reason) {
            case 0:
                reason = 'Desconectado a nivel de red';
                break;
            case 1:
                reason = 'Versión de protocolo MQTT incompatible';
                break;
            case 2:
                reason = 'Identificador rechazado';
                break;
            case 3:
                reason = 'Servidor no disponible';
                break;
            case 4:
                reason = 'Credenciales mal formadas';
                break;
            case 5:
                reason = 'No autorizado';
                break;
            case 6:
                reason = 'No hay memoria suficiente';
                break;
            case 7:
                reason = 'Huella TLS incorrecta';
                break;
            }
            span_reason.text(reason);
        }

        mqttpane.find('form input#mqtthost').val(data.host);
        mqttpane.find('form input#mqttport').val(data.port);
        if (data.user != null) {
            mqttpane.find('form input#mqttuser').val(data.user);
            mqttpane.find('form input#mqttpass').val(data.pass);
            mqttpane.find('input[name=mqttauth]#on').click();
        } else {
            mqttpane.find('form input#mqttuser').val('');
            mqttpane.find('form input#mqttpass').val('');
            mqttpane.find('input[name=mqttauth]#off').click();
        }

        if (data.tls_capable) {
            // Hay soporte TLS
            mqttpane.find('div.mqtt-tls').show();

            // Nivel de soporte TLS deseado
            mqttpane.find('input[name=tls_verifylevel]#tls_verifylevel_'+data.tls_verifylevel).click();

            // Archivos de certificados presentes en servidor
            mqttpane.find('form span#tls_servercert_present')
                .removeClass('badge-warning badge-success')
                .addClass(data.tls_servercert ? 'badge-success' : 'badge-warning')
                .text(data.tls_servercert ? 'SÍ' : 'NO');
            mqttpane.find('form span#tls_clientcert_present')
                .removeClass('badge-warning badge-success')
                .addClass(data.tls_clientcert ? 'badge-success' : 'badge-warning')
                .text(data.tls_clientcert ? 'SÍ' : 'NO');
        } else {
            // No hay soporte TLS
            mqttpane.find('div.mqtt-tls').hide();
        }
    })
    .fail(function (e) { yuboxStdAjaxFailHandler(e, 2000); });
}

function yuboxUploadMQTTCerts(route_upload, filelist)
{
    var mqttpane = getYuboxPane('mqtt');

    if (typeof FormData == 'undefined') {
        yuboxMostrarAlertText('danger', 'Este navegador no soporta FormData para subida de datos. Actualice su navegador.', 2000);
        return;
    }
    var postData = new FormData();

    for (let k of filelist) {
        let fi = mqttpane.find('input[type=file]#'+k);
        if (fi[0].files.length <= 0) {
            yuboxMostrarAlertText('danger', 'Es necesario elegir un archivo de certificado: '+k, 2000);
            return;
        }
        postData.append(k, fi[0].files[0]);
    }
    $.post({
        url: route_upload,
        data: postData,
        processData: false,
        contentType: false
    })
    .done(function (data) {
        if (data.success) {
            // Al aplicar actualización debería recargarse más tarde
            yuboxMostrarAlertText('success', data.msg, 5000);
            setTimeout(function () {
                yuboxLoadMqttConfig();
            }, 5 * 1000);
        } else {
            yuboxMostrarAlertText('danger', data.msg, 6000);
        }
    })
    .fail(function (e) {
        yuboxStdAjaxFailHandler(e, 5000);
    });
}
function setupWebAuthTab()
{
    //
    var authpane = getYuboxPane('webauth');

    // https://getbootstrap.com/docs/4.4/components/navs/#events
    getYuboxNavTab('webauth').on('shown.bs.tab', function (e) {
        var authpane = getYuboxPane('webauth');
        $.getJSON(yuboxAPI('authconfig'))
        .done(function (data) {
            authpane.find('input#yubox_username').val(data.username);
            authpane.find('input#yubox_password1, input#yubox_password2').val(data.password);
        })
        .fail(function (e) { yuboxStdAjaxFailHandler(e, 2000); });
    });
    authpane.find('button[name=apply]').click(function () {
        var postData = {
            password1: authpane.find('input#yubox_password1').val(),
            password2: authpane.find('input#yubox_password2').val()
        };
        if (postData.password1 != postData.password2) {
            yuboxMostrarAlertText('danger', 'Contraseña y confirmación no coinciden.', 5000);
        } else if (postData.password1 == '') {
            yuboxMostrarAlertText('danger', 'Contraseña no puede estar vacía.', 5000);
        } else {
            $.post(yuboxAPI('authconfig'), postData)
            .done(function (data) {
                if (data.success) {
                    // Al guardar correctamente las credenciales, recargar para que las pida
                    yuboxMostrarAlertText('success', data.msg, 2000);
                    setTimeout(function () {
                        window.location.reload();
                    }, 3 * 1000);
                } else {
                    yuboxMostrarAlertText('danger', data.msg, 2000);
                }
            })
            .fail(function (e) { yuboxStdAjaxFailHandler(e, 2000); });
        }
    });
}

function setupYuboxOTATab()
{
    var otapane = getYuboxPane('yuboxOTA');
    var data = {
        'sse':  null
    };
    otapane.data(data);

    // https://getbootstrap.com/docs/4.4/components/navs/#events
    getYuboxNavTab('yuboxOTA').on('shown.bs.tab', function (e) {
        var otapane = getYuboxPane('yuboxOTA');

        // Si el control select de la lista de firmwares está DESACTIVADO,
        // se asume que esta sesión todavía está subiendo algo al equipo.
        if (otapane.find('select#yuboxfirmwarelist').prop('disabled')) {
            return;
        }

        $.get(yuboxAPI('yuboxOTA')+'/firmwarelist.json')
        .done(function (data) {
            var sel_firmwarelist = otapane.find('select#yuboxfirmwarelist');
            sel_firmwarelist.empty();
            for (var i = 0; i < data.length; i++) {
                var opt = $('<option></option>');
                opt.attr('value', data[i].tag)
                opt.text(data[i].desc);
                opt.data(data[i])
                sel_firmwarelist.append(opt);
            }
            sel_firmwarelist.val(data[0].tag);
            sel_firmwarelist.change();
        })
        .fail(function (e) { yuboxStdAjaxFailHandler(e, 2000); });

    });

    otapane.find('select#yuboxfirmwarelist').change(function() {
        var otapane = getYuboxPane('yuboxOTA');

        var opt = $(this).find('option:selected').first();
        otapane.find('span.yubox-firmware-desc').text(opt.data('desc'));

        $.get(opt.data('rollback'))
        .done(function (data) {
            var spanRB = otapane.find('span#canrollback');
            var btnRB = otapane.find('button[name="rollback"]');

            spanRB.removeClass('badge-danger badge-success');
            if (data.canrollback) {
                spanRB
                    .addClass('badge-success')
                    .text('RESTAURABLE');
                btnRB.prop('disabled', false);
            } else {
                spanRB
                    .addClass('badge-danger')
                    .text('NO RESTAURABLE');
                btnRB.prop('disabled', true);
            }
        })
        .fail(function (e) { yuboxStdAjaxFailHandler(e, 5000); });
    });

    otapane.find('input[type=file]#tgzupload').change(function () {
        var lbl = $(this).next('label#lbl-tgzupload');
        if (lbl.data('default') == undefined) {
            // Almacenar texto original para restaurar si archivo vacío
            lbl.data('default', lbl.text())
        }
        var txt = ($(this)[0].files.length > 0)
            ? $(this)[0].files[0].name
            : lbl.data('default');
        lbl.text(txt);
    });
    otapane.find('button[name=apply]').click(function () {
        var route_tgzupload = otapane.find('select#yuboxfirmwarelist > option:selected').first().data('tgzupload');

        var fi = otapane.find('input[type=file]#tgzupload');
        if (fi[0].files.length <= 0) {
            yuboxMostrarAlertText('danger', 'Es necesario elegir un archivo tgz para actualización.', 2000);
            return;
        }
        if (typeof FormData == 'undefined') {
            yuboxMostrarAlertText('danger', 'Este navegador no soporta FormData para subida de datos. Actualice su navegador.', 2000);
            return;
        }
        var postData = new FormData();
        postData.append('tgzupload', fi[0].files[0]);
        yuboxOTAUpload_init();
        $.post({
            url: route_tgzupload,
            data: postData,
            processData: false,
            contentType: false
        })
        .done(function (data) {
            if (data.success) {
                // Al aplicar actualización debería recargarse más tarde
                yuboxMostrarAlertText('success', data.msg, 5000);
                setTimeout(function () {
                    window.location.reload();
                }, 10 * 1000);

                if (data.reboot) {
                    // Por haber recibido esta indicación, ya se sabe que el
                    // dispositivo está listo para ser reiniciado.
                    $.post(yuboxAPI('yuboxOTA')+'/reboot', {})
                    .fail(function (e) {
                        yuboxStdAjaxFailHandler(e, 5000);
                    });
                }
            } else {
                yuboxMostrarAlertText('danger', data.msg, 6000);
            }
            yuboxOTAUpload_shutdown();
        })
        .fail(function (e) {
            yuboxStdAjaxFailHandler(e, 5000);
            yuboxOTAUpload_shutdown();
        });
    });
    otapane.find('button[name=rollback]').click(function () {
        var route_rollback = otapane.find('select#yuboxfirmwarelist > option:selected').first().data('rollback');

        yuboxOTAUpload_setDisableBtns(true);
        $.post(route_rollback, {})
        .done(function (data) {
            if (data.success) {
                // Al aplicar actualización debería recargarse más tarde
                yuboxMostrarAlertText('success', data.msg, 4000);
                setTimeout(function () {
                    window.location.reload();
                }, 10 * 1000);
            } else {
                yuboxMostrarAlertText('danger', data.msg, 2000);
            }
            yuboxOTAUpload_setDisableBtns(false);
        })
        .fail(function (e) {
            yuboxStdAjaxFailHandler(e, 5000);
            yuboxOTAUpload_setDisableBtns(false);
        });
    });
    otapane.find('button[name=reboot]').click(function () {
        yuboxOTAUpload_setDisableBtns(true);
        $.post(yuboxAPI('yuboxOTA')+'/reboot', {})
        .done(function (data) {
            if (data.success) {
                // Al aplicar actualización debería recargarse más tarde
                yuboxMostrarAlertText('success', data.msg, 4000);
                setTimeout(function () {
                    window.location.reload();
                }, 10 * 1000);
            } else {
                yuboxMostrarAlertText('danger', data.msg, 2000);
            }
            yuboxOTAUpload_setDisableBtns(false);
        })
        .fail(function (e) {
            yuboxStdAjaxFailHandler(e, 5000);
            yuboxOTAUpload_setDisableBtns(false);
        });
    });

    // Diálogo modal de reporte de hardware
    otapane.find('button[name=hwreport]').click(function () {
        $.getJSON(yuboxAPI('yuboxOTA')+'/hwreport.json')
        .done(function (data) {
            var dlg_hwinfo = otapane.find('div#hwreport');
            var hwtable = dlg_hwinfo.find('table#hwinfo > tbody');

            // Formatos especiales para algunos campos
            data.ARDUINO_ESP32_GIT_VER = data.ARDUINO_ESP32_GIT_VER.toString(16);
            data.EFUSE_MAC = data.EFUSE_MAC.toString(16);
            data.CPU_MHZ = data.CPU_MHZ + ' MHz';
            data.FLASH_SPEED = (data.FLASH_SPEED / 1000000) + ' MHz';

            for (const key in data) {
                hwtable.find('tr#'+key+' > td.text-muted').text(data[key]);
            }

            dlg_hwinfo.modal({ focus: true });
        })
        .fail(function (e) { yuboxStdAjaxFailHandler(e, 2000); });
    });
}

function yuboxOTAUpload_init()
{
    yuboxOTAUpload_setDisableBtns(true);

    var otapane = getYuboxPane('yuboxOTA');
    yuboxOTAUpload_setProgressBar(0);
    otapane.find('div.upload-progress span#filename').text('-');
    otapane.find('div.upload-progress span#current').text('0');
    otapane.find('div.upload-progress span#total').text('0');
    otapane.find('div.upload-progress span#currupload').text('0');
    otapane.find('div.upload-progress').show();

    if (!!window.EventSource) {
        var sse = new EventSource(yuboxAPI('yuboxOTA')+'/events');
        sse.addEventListener('uploadFileStart', function (e) {
            var data = $.parseJSON(e.data);
            var totalKB = data.total / 1024.0;
            var currUploadKB = data.currupload / 1024.0;
            otapane.find('div.upload-progress span#filename').text(data.filename);
            otapane.find('div.upload-progress span#current').text(0);
            otapane.find('div.upload-progress span#total').text(totalKB.toFixed(1));
            otapane.find('div.upload-progress span#currupload').text(currUploadKB.toFixed(1));
            otapane.find('div.progress-bar')
                .removeClass('bg-info bg-danger')
                .addClass(data.firmware ? 'bg-danger' : 'bg-info');
            yuboxOTAUpload_setProgressBar(0);
        });
        sse.addEventListener('uploadFileProgress', function (e) {
            var data = $.parseJSON(e.data);
            var totalKB = data.total / 1024.0;
            var currKB = data.current / 1024.0;
            var currUploadKB = data.currupload / 1024.0;
            otapane.find('div.upload-progress span#filename').text(data.filename);
            otapane.find('div.upload-progress span#total').text(totalKB.toFixed(1));
            otapane.find('div.upload-progress span#current').text(currKB.toFixed(1));
            otapane.find('div.upload-progress span#currupload').text(currUploadKB.toFixed(1));
            yuboxOTAUpload_setProgressBar(totalKB > 0.0 ? 100.0 * currKB / totalKB : 0);
        });
        sse.addEventListener('uploadFileEnd', function (e) {
            var data = $.parseJSON(e.data);
            var totalKB = data.total / 1024.0;
            var currUploadKB = data.currupload / 1024.0;
            otapane.find('div.upload-progress span#filename').text(data.filename);
            otapane.find('div.upload-progress span#current').text(totalKB.toFixed(1));
            otapane.find('div.upload-progress span#total').text(totalKB.toFixed(1));
            otapane.find('div.upload-progress span#currupload').text(currUploadKB.toFixed(1));
            yuboxOTAUpload_setProgressBar(100);
        });
        sse.addEventListener('uploadPostTask', function (e) {
	        var data = $.parseJSON(e.data);
	        var msg = data.task;
	        var taskDesc = {
                'firmware-commit-start':		'Iniciando commit de firmware nuevo',
                'firmware-commit-failed':		'Falló el commit de firmware nuevo',
                'firmware-commit-end':			'Finalizado commit de firmware nuevo',
                'datafiles-load-oldmanifest':	'Cargando lista de archivos de datos viejos',
                'datafiles-delete-oldbackup':	'Borrando respaldo anterior de archivos de datos',
                'datafiles-rename-oldfiles':	'Respaldando archivos de datos viejos',
                'datafiles-rename-newfiles':	'Instalando archivos de datos nuevos',
                'datafiles-end':				'Fin de instalación de archivos de datos'
	        };
	        if (taskDesc[data.task] != undefined) msg = taskDesc[data.task];
	        yuboxOTAUpload_setProgressBarMessage(100, msg);
        });
        otapane.data('sse', sse);
    } else {
      yuboxMostrarAlertText('danger', 'Este navegador no soporta Server-Sent Events, no se puede monitorear upload.');
    }
}

function yuboxOTAUpload_shutdown()
{
    yuboxOTAUpload_setDisableBtns(false);
    var otapane = getYuboxPane('yuboxOTA');
    otapane.find('div.upload-progress').hide();
    if (otapane.data('sse') != null) {
        otapane.data('sse').close();
        otapane.data('sse', null);
    }
}

function yuboxOTAUpload_setDisableBtns(v)
{
    var otapane = getYuboxPane('yuboxOTA');
    otapane.find('button[name=apply], button[name=rollback], button[name=reboot], select#yuboxfirmwarelist').prop('disabled', v);
}

function yuboxOTAUpload_setProgressBar(v)
{
    yuboxOTAUpload_setProgressBarMessage(v, v.toFixed(1) + ' %');
}

function yuboxOTAUpload_setProgressBarMessage(v, msg)
{
    var otapane = getYuboxPane('yuboxOTA');
    var pb = otapane.find('div.progress-bar');
    pb.css('width', v+'%');
    pb.attr('aria-valuenow', v);
    pb.text(msg);
}


function yuboxAPI(s)
{
    var mockup =  window.location.pathname.startsWith('/yubox-mockup/');
    return mockup
        ? '/yubox-mockup/'+s+'.php'
        : '/yubox-api/'+s;
}

function yuboxMostrarAlertText(alertstyle, text, timeout)
{
    var content = $('<span></span>').text(text);
    return yuboxMostrarAlert(alertstyle, content, timeout);
}

function yuboxMostrarAlert(alertstyle, content, timeout)
{
    return yuboxDlgMostrarAlert('main > div.container', alertstyle, content, timeout);
}

function yuboxDlgMostrarAlertText(basesel, alertstyle, text, timeout)
{
    var content = $('<span></span>').text(text);
    return yuboxDlgMostrarAlert(basesel, alertstyle, content, timeout);
}

function yuboxDlgMostrarAlert(basesel, alertstyle, content, timeout)
{
    var al = $(basesel).children('div.alert.yubox-alert-template')
        .clone()
        .removeClass('yubox-alert-template')
        .addClass('yubox-alert')
        .addClass('alert-'+alertstyle);
    al.find('button.close').before(content);

    $(basesel).children('div.yubox-alert').remove();
    $(basesel).children('div.alert.yubox-alert-template').after(al);
    if (timeout != undefined) {
        setTimeout(function() {
            al.remove();
        }, timeout);
    }

    return al;
}

function yuboxStdAjaxFailHandler(e, timeout)
{
    yuboxStdAjaxFailHandlerDlg('main > div.container', e, timeout);
}

function yuboxStdAjaxFailHandlerDlg(basesel, e, timeout)
{
    var msg;
    if (e.status == 0) {
        msg = 'Fallo al contactar dispositivo';
    } else if (e.responseJSON == undefined) {
        msg = 'Tipo de contenido inesperado en respuesta';
    } else {
        msg = e.responseJSON.msg;
    }
    yuboxDlgMostrarAlertText(basesel, 'danger', msg, timeout);
}

function getYuboxPane(modname) { return $('div#yuboxMainTabContent > div.tab-pane#'+modname); }
function getYuboxNavTab(modname) { return $('ul#yuboxMainTab a#'+modname+'-tab[data-toggle="tab"]'); }