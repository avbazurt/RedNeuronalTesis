if (document.readyState == 'loading') {
    document.addEventListener('DOMContentLoaded', yuboxSetupAllTabs);
} else {
    yuboxSetupAllTabs();
}

function yuboxSetupAllTabs()
{
    setupLectorTab();
    setupWiFiTab();
    setupNTPConfTab();
    setupMqttTab();
    setupWebAuthTab();
    setupYuboxOTATab();

    // Mostrar el tab preparado por omisión como activo
    const tab = document.querySelector('ul#yuboxMainTab a.set-active');
    tab.classList.remove('set-active');
    yuboxWrapJQ(tab).tab('show');   // <-- Bootstrap 4 requiere jQuery
}

function setupLectorTab()
{
    var lectorpane = getYuboxPane('lector', true);
    var data = {
        'sse':  null,
        'chart': null,
    };
    lectorpane.data = data;

    var ctx = lectorpane.querySelector('canvas#atmospheric').getContext('2d');
    var chtData = {
        datasets:   [{
            label:  'Presión',
            borderColor: "rgb(255, 99, 132)",
            backgroundColor: "rgb(255, 99, 132)",
            fill: false,
            data: [],
            yAxisID: 'press'
        },{
            label:  'Temperatura',
            borderColor: "rgb(54, 162, 235)",
            backgroundColor: "rgb(54, 162, 235)",
            fill: false,
            data: [],
            yAxisID: 'temp'
        }]
    };
    var cht = new Chart(ctx, {
        type:       'line',
        data:       chtData,
        options:    {
            responsive: true,
            hoverMode: 'index',
            stacked: false,
            title: {
                display: true,
                text: 'Presión y temperatura'
            },
            scales: {
                xAxes:  [{
                    type:   'time'
                }],
                yAxes:  [{
                    type: 'linear',
                    display: true,
                    position: 'left',
                    id: 'press'
                },{
                    type: 'linear',
                    display: true,
                    position: 'right',
                    id: 'temp'
                }]
            }
        }
    });
    lectorpane.data['chart'] = cht;

    if (!!window.EventSource) {
        var sse = new EventSource(yuboxAPI('lectura')+'/events');
        sse.addEventListener('message', function (e) {
            var data = JSON.parse(e.data);
            yuboxLector_actualizar(new Date(data.ts), data.pressure, data.temperature);
        });
        lectorpane.data['sse'] = sse;
    }
}

function yuboxLector_actualizar(d, p, t)
{
    var lectorpane = getYuboxPane('lector', true);
    lectorpane.querySelector('h3#temp').textContent = t.toFixed(2);
    lectorpane.querySelector('h3#press').textContent = p.toFixed(2);
    var cht = lectorpane.data['chart'];
    cht.data.datasets[0].data.push({x: d, y: p});
    cht.data.datasets[1].data.push({x: d, y: t});
    if (d.valueOf() - cht.data.datasets[0].data[0].x.valueOf() > 10 * 60 * 1000) {
        cht.data.datasets[0].data.shift();
        cht.data.datasets[1].data.shift();
    }
    cht.update();
}

function setupWiFiTab()
{
    const wifipane = getYuboxPane('wifi', true);
    var data = {
        'sse':                  null,
        'wifiscan-template':    wifipane.querySelector('table#wifiscan > tbody > tr.template'),
        'wifinetworks-template':wifipane.querySelector('div#wifi-networks table#wifi-saved-networks > tbody > tr.template')
    }
    data['wifiscan-template'].classList.remove('template');
    data['wifiscan-template'].remove();
    data['wifinetworks-template'].classList.remove('template');
    data['wifinetworks-template'].remove();
    wifipane.data = data;

    // https://getbootstrap.com/docs/4.4/components/navs/#events
    getYuboxNavTab('wifi')
    .on('shown.bs.tab', function (e) {
        yuboxWiFi_setupWiFiScanListener();
    })
    .on('hide.bs.tab', function (e) {
        if (wifipane.data['sse'] != null) {
          wifipane.data['sse'].close();
          wifipane.data['sse'] = null;
        }
    });

    // Qué hay que hacer al hacer clic en una fila que representa la red
    wifipane.querySelector('table#wifiscan > tbody').addEventListener('click', function(e) {
        let currentTarget = null;
        for (let target = e.target; target && target != this; target = target.parentNode ) {
            if (target.matches('tr')) {
                currentTarget = target;
                break;
            }
        }
        if (currentTarget == null) return;

        var net = currentTarget.data;
        if (net.connected) {
            yuboxFetch('wificonfig', 'connection')
            .then((data) => {
                const dlg_wifiinfo = wifipane.querySelector('div#wifi-details');

                var res = evaluarIntensidadRedWifi(dlg_wifiinfo.querySelector('tr#rssi > td > svg.wifipower'), data.rssi);
                dlg_wifiinfo.querySelector('tr#rssi > td.text-muted').textContent = (res.diag + ' ('+res.pwr+' %)');

                dlg_wifiinfo.querySelectorAll('tr#auth > td > svg.wifiauth > path')
                    .forEach((el) => { el.style.display = 'none'; });
                dlg_wifiinfo.querySelector('tr#auth > td > svg.wifiauth > path.'+(net.authmode != 0 ? 'locked' : 'unlocked'))
                    .style.display = '';
                dlg_wifiinfo.querySelector('tr#auth > td.text-muted').textContent = (wifiauth_desc(net.authmode));

                dlg_wifiinfo.querySelector('tr#bssid > td.text-muted').textContent = (net.ap[0].bssid);
                dlg_wifiinfo.querySelector('tr#channel > td.text-muted').textContent = (net.ap[0].channel);

                dlg_wifiinfo.querySelector('h5#wifi-details-title').textContent = (data.ssid);
                dlg_wifiinfo.querySelector('input#ssid').value = (data.ssid);
                dlg_wifiinfo.querySelector('div#netinfo div#mac').textContent = (data.mac);
                dlg_wifiinfo.querySelector('div#netinfo div#ipv4').textContent = (data.ipv4);
                dlg_wifiinfo.querySelector('div#netinfo div#gateway').textContent = (data.gateway);
                dlg_wifiinfo.querySelector('div#netinfo div#netmask').textContent = (data.netmask);

                const div_dns = dlg_wifiinfo.querySelector('div#netinfo div#dns');
                while (div_dns.firstChild) div_dns.removeChild(div_dns.firstChild);
                for (var i = 0; i < data.dns.length; i++) {
                    let r = document.createElement('div'); r.classList.add('row');
                    let c = document.createElement('div'); c.classList.add('col');
                    c.textContent = (data.dns[i]);
                    r.appendChild(c);
                    div_dns.appendChild(r);
                }

                // Diálogo modal Bootstrap 4 requiere jQuery
                $(dlg_wifiinfo).modal({ focus: true });
            }, (e) => { yuboxStdAjaxFailHandler(e, 2000); });
        } else {
            yuboxWiFi_displayNetworkDialog('scanned', net);
        }
    });
    wifipane.querySelector('div#wifi-credentials select#authmode').addEventListener('change', function () {
        const dlg_wificred = wifipane.querySelector('div#wifi-credentials');
        var authmode = this.value;

        dlg_wificred.querySelectorAll('div.form-group.wifi-auth')
            .forEach((el) => { el.style.display = 'none'; });
        dlg_wificred.querySelectorAll('div.form-group.wifi-auth input')
            .forEach((el) => { el.value = ''; });
        dlg_wificred.querySelector('button[name=connect]').disabled = true;
        if (authmode == 5) {
            // Autenticación WPA-ENTERPRISE
            dlg_wificred.querySelectorAll('div.form-group.wifi-auth-eap')
                .forEach((el) => { el.style.display = ''; });
            dlg_wificred.querySelector('div.form-group.wifi-auth-eap input#password')
                .dispatchEvent(new Event('change'));
        } else if (authmode > 0) {
            // Autenticación con contraseña
            dlg_wificred.querySelectorAll('div.form-group.wifi-auth-psk')
                .forEach((el) => { el.style.display = ''; });
            dlg_wificred.querySelector('div.form-group.wifi-auth-psk input#psk')
                .dispatchEvent(new Event('change'));
        } else {
            // Red sin autenticación, activar directamente opción de conectar
            dlg_wificred.querySelector('button[name=connect]').disabled = false;
        }
    });

    // Qué hay que hacer al hacer clic en el botón de Redes Guardadas
    wifipane.querySelector('button[name=networks]').addEventListener('click', function () {
        yuboxFetch('wificonfig', 'networks')
        .then((data) => {
            const dlg_wifinetworks = wifipane.querySelector('div#wifi-networks');
            const tbody_wifinetworks = dlg_wifinetworks.querySelector('table#wifi-saved-networks > tbody');
            while (tbody_wifinetworks.firstChild) tbody_wifinetworks.removeChild(tbody_wifinetworks.firstChild);

            data.forEach(function (net) {
                let tr_wifinet = wifipane.data['wifinetworks-template'].cloneNode(true);
                tr_wifinet.data = {'ssid': net.ssid};
                tr_wifinet.querySelector('td#ssid').textContent = (net.ssid);
                if (net.identity != null) {
                    // Autenticación WPA-ENTERPRISE
                    tr_wifinet.querySelector('td#auth').title = 'Seguridad: ' + wifiauth_desc(5);
                    tr_wifinet.querySelector('td#auth > svg.wifiauth > path.locked').style.display = '';
                } else if (net.psk != null) {
                    // Autenticación PSK
                    tr_wifinet.querySelector('td#auth').title = 'Seguridad: ' + wifiauth_desc(4);
                    tr_wifinet.querySelector('td#auth > svg.wifiauth > path.locked').style.display = '';
                } else {
                    // Sin autenticación
                    tr_wifinet.querySelector('td#auth').title = 'Seguridad: ' + wifiauth_desc(0);
                    tr_wifinet.querySelector('td#auth > svg.wifiauth > path.unlocked').style.display = '';
                }
                tbody_wifinetworks.appendChild(tr_wifinet);
            });

            // Diálogo modal Bootstrap 4 requiere jQuery
            $(dlg_wifinetworks).modal({ focus: true });
        }, (e) => { yuboxStdAjaxFailHandler(e, 2000); });
    });

    // Qué hay que hacer al hacer clic en el botón de Agregar red .
    // NOTA: hay 2 botones que se llaman igual. Uno en la interfaz principal, y el otro
    // en el diálogo de mostrar las redes guardadas. El comportamiento a continuación
    // define la acción para AMBOS botones.
    let addnet_cb = function () {
        const dlg_wifinetworks = wifipane.querySelector('div#wifi-networks');
        if (dlg_wifinetworks.classList.contains('show')) {
            // Diálogo modal Bootstrap 4 requiere jQuery
            $(dlg_wifinetworks).modal('hide');
        }
        yuboxWiFi_displayNetworkDialog('manual', { authmode : 4, psk: null});
    };
    wifipane.querySelectorAll('button[name=addnet]')
        .forEach((el) => { el.addEventListener('click', addnet_cb); });

    // Qué hay que hacer al hacer clic en una fila de red guardada
    wifipane.querySelector('div#wifi-networks table#wifi-saved-networks > tbody').addEventListener('click', function(e) {
        let currentTarget = null;
        for (let target = e.target; target && target != this; target = target.parentNode ) {
            if (target.matches('tr td#delete button.btn-danger')) {
                currentTarget = target;
                break;
            }
        }
        if (currentTarget == null) return;

        const dlg_wifinetworks = wifipane.querySelector('div#wifi-networks');
        let tr_wifinet = currentTarget; while (tr_wifinet && !tr_wifinet.matches('tr')) tr_wifinet = tr_wifinet.parentNode;
        let ssid = tr_wifinet.data['ssid'];

        if (!confirm("Presione OK para OLVIDAR las credenciales de la red "+ssid)) return;

        yuboxFetchMethod('DELETE', 'wificonfig', 'networks/'+ssid)
        .then((data) => {
            // Credenciales borradas
            tr_wifinet.parentNode.removeChild(tr_wifinet);
        }, (e) => {
            yuboxStdAjaxFailHandlerDlg(dlg_wifinetworks.querySelector('div.modal-body'), e, 2000);
        });
    });

    // Comportamiento de controles de diálogo de ingresar credenciales red
    const dlg_wificred = wifipane.querySelector('div#wifi-credentials');
    dlg_wificred.querySelectorAll('div.form-group.wifi-auth-eap input').forEach((el) => {
        ['change', 'keypress', 'blur'].forEach((k) => { el.addEventListener(k, checkValidWifiCred_EAP); });
    });
    dlg_wificred.querySelectorAll('div.form-group.wifi-auth-psk input').forEach((el) => {
        ['change', 'keypress', 'blur'].forEach((k) => { el.addEventListener(k, checkValidWifiCred_PSK); });
    });
    dlg_wificred.querySelector('div.modal-footer button[name=connect]').addEventListener('click', function () {
        const modalbody = dlg_wificred.querySelector('div.modal-body');
        let netclass = null;
        ['scanned', 'manual'].forEach((k) => { if (modalbody.classList.contains(k)) netclass = k; });
        if (netclass == null) {
            console.warn('YUBOX Framework', 'No se encuentra netclass en div.modal-body');
            return;
        }

        let postData = {
            ssid:       dlg_wificred.querySelector('input#ssid').value,
            authmode:   parseInt(dlg_wificred.querySelector((netclass == 'scanned') ? 'input#authmode' : 'select#authmode').value),
        };
        if (netclass == 'scanned') postData['pin'] = dlg_wificred.querySelector('input[name="pin"]:checked').value;
        ((postData.authmode == 5) ? ['identity', 'password'] : (postData.authmode > 0) ? ['psk'] : [])
            .forEach((k) => { postData[k] = dlg_wificred.querySelector('div.form-group input#'+k).value; });

        if (netclass == 'scanned') {
            // Puede ocurrir que la red ya no exista según el escaneo más reciente
            let existe = (Array.from(wifipane.querySelectorAll('table#wifiscan > tbody > tr'))
                .filter((tr) => { return (tr.data['ssid'] == postData.ssid); })
                .length > 0);
            if (!existe) {
                // Diálogo modal Bootstrap 4 requiere jQuery
                $(dlg_wificred).modal('hide');
                yuboxMostrarAlertText('warning', 'La red '+postData.ssid+' ya no se encuentra disponible', 3000);
                return;
            }
        }

        // La red todavía existe en el último escaneo. Se intenta conectar.
        yuboxFetchMethod(
            (netclass == 'scanned') ? 'PUT' : 'POST',
            'wificonfig',
            (netclass == 'scanned') ? 'connection' : 'networks',
            postData
        ).then((data) => {
            // Credenciales aceptadas, se espera a que se conecte
            if (netclass == 'scanned') {
                marcarRedDesconectandose();
            }
            // Diálogo modal Bootstrap 4 requiere jQuery
            $(dlg_wificred).modal('hide');
        }, (e) => {
            yuboxStdAjaxFailHandlerDlg(dlg_wificred.querySelector('div.modal-body'), e, 2000);
        });
    });

    // Comportamiento de controles de diálogo de mostrar estado de red conectada
    const dlg_wifiinfo = wifipane.querySelector('div#wifi-details');
    dlg_wifiinfo.querySelector('div.modal-footer button[name=forget]').addEventListener('click', function () {
        yuboxFetchMethod('DELETE', 'wificonfig', 'connection')
        .then((data) => {
            // Credenciales aceptadas, se espera a que se conecte
            marcarRedDesconectandose();
            // Diálogo modal Bootstrap 4 requiere jQuery
            $(dlg_wifiinfo).modal('hide');
        }, (e) => {
            yuboxStdAjaxFailHandlerDlg(dlg_wifiinfo.querySelector('div.modal-body'), e, 2000);
        });
    });
}

function yuboxWiFi_displayNetworkDialog(netclass, net)
{
    const wifipane = getYuboxPane('wifi', true);
    const dlg_wificred = wifipane.querySelector('div#wifi-credentials');

    // Preparar diálogo para red manual o escaneada
    const modalbody = dlg_wificred.querySelector('div.modal-body');
    modalbody.classList.remove('manual', 'scanned');
    modalbody.classList.add(netclass);

    dlg_wificred.querySelector('h5#wifi-credentials-title').textContent = (netclass == 'scanned') ? net.ssid : 'Agregar red';
    if (netclass == 'scanned') {
        dlg_wificred.querySelector('input#ssid').value = (net.ssid);
        dlg_wificred.querySelector('input#key_mgmt').value = (wifiauth_desc(net.authmode));
        dlg_wificred.querySelector('input#authmode').value = (net.authmode);
        dlg_wificred.querySelector('input#bssid').value = (net.ap[0].bssid);
        dlg_wificred.querySelector('input#channel').value = (net.ap[0].channel);
    } else {
        dlg_wificred.querySelector('input#ssid').value = ('');
    }
    dlg_wificred.querySelector('input[name="pin"]#N').click();

    const sel_authmode = dlg_wificred.querySelector('select#authmode');
    if (net.authmode == 5) {
        // Autenticación WPA-ENTERPRISE
        dlg_wificred.querySelector('div.form-group.wifi-auth-eap input#identity')
            .value = ((net.identity != null) ? net.identity : '');
        dlg_wificred.querySelector('div.form-group.wifi-auth-eap input#password')
            .value = ((net.password != null) ? net.password : '');
        sel_authmode.value = (5);
    } else if (net.authmode > 0) {
        // Autenticación con contraseña
        dlg_wificred.querySelector('div.form-group.wifi-auth-psk input#psk')
            .value = ((net.psk != null) ? net.psk : '');
        sel_authmode.value = (4);
    } else {
        // Red sin autenticación
        sel_authmode.value = (0);
    }
    sel_authmode.dispatchEvent(new Event('change'));
    dlg_wificred.querySelector('div.modal-footer button[name=connect]')
        .textContent = (netclass == 'scanned') ? 'Conectar a WIFI' : 'Guardar';

    // Diálogo modal Bootstrap 4 requiere jQuery
    $(dlg_wificred).modal({ focus: true });
}

function checkValidWifiCred_EAP()
{
    // Activar el botón de enviar credenciales si ambos valores son no-vacíos
    const wifipane = getYuboxPane('wifi', true);
    const dlg_wificred = wifipane.querySelector('div#wifi-credentials');
    var numLlenos = Array.from(dlg_wificred.querySelectorAll('div.form-group.wifi-auth-eap input'))
        .filter(function(inp) { return (inp.value != ''); })
        .length;
    dlg_wificred.querySelector('button[name=connect]').disabled = !(numLlenos >= 2);
}

function checkValidWifiCred_PSK()
{
    // Activar el botón de enviar credenciales si la clave es de al menos 8 caracteres
    const wifipane = getYuboxPane('wifi', true);
    const dlg_wificred = wifipane.querySelector('div#wifi-credentials');
    var psk = dlg_wificred.querySelector('div.form-group.wifi-auth-psk input#psk').value;
    dlg_wificred.querySelector('button[name=connect]').disabled = !(psk.length >= 8);
}

function yuboxWiFi_isTabActive()
{
    return getYuboxNavTab('wifi', true).classList.contains('active');
}

function yuboxWiFi_setupWiFiScanListener()
{
    if (!yuboxWiFi_isTabActive()) {
        // El tab de WIFI ya no está visible, no se hace nada
        return;
    }

    const wifipane = getYuboxPane('wifi', true);
    if (!!window.EventSource) {
        var sse = new EventSource(yuboxAPI('wificonfig')+'/netscan');
        sse.addEventListener('WiFiScanResult', function (e) {
          var data = JSON.parse(e.data);
          yuboxWiFi_actualizarRedes(data);
        });
        sse.addEventListener('WiFiStatus', function (e) {
            var data = JSON.parse(e.data);
            if (!data.yubox_control_wifi) {
              yuboxMostrarAlertText('warning',
                'YUBOX Now ha cedido control del WiFi a otra librería. El escaneo WiFi podría no refrescarse, o mostrar datos desactualizados.',
                5000);
            }
        });
        sse.addEventListener('error', function (e) {
          mostrarReintentoScanWifi('Se ha perdido conexión con dispositivo para siguiente escaneo');
        });
        wifipane.data['sse'] = sse;
    } else {
        yuboxMostrarAlertText('danger', 'Este navegador no soporta Server-Sent Events, no se puede escanear WiFi.');
    }
}

function yuboxWiFi_actualizarRedes(data)
{
    const wifipane = getYuboxPane('wifi', true);

    data.sort(function (a, b) {
        if (a.connected || a.connfail) return -1;
        if (b.connected || b.connfail) return 1;
        return b.rssi - a.rssi;
    });

    const tbody_wifiscan = wifipane.querySelector('table#wifiscan > tbody');
    while (tbody_wifiscan.firstChild) tbody_wifiscan.removeChild(tbody_wifiscan.firstChild);
    const dlg_wifiinfo = wifipane.querySelector('div#wifi-details');
    var ssid_visible = null;
    if (dlg_wifiinfo.classList.contains('show')) {
        ssid_visible = dlg_wifiinfo.querySelector('input#ssid').value;
    }
    var max_rssi = null;
    data.forEach(function (net) {
        // Buscar en la lista existente la fila de quien tenga el SSID indicado.
        var tr_wifiscan;
        var f = Array.from(tbody_wifiscan.querySelectorAll('tr'))
        .filter(function(tr) { return (tr.data['ssid'] == net.ssid); });
        if (f.length > 0) {
            // Se encontró SSID duplicado. Se asume que primero aparece el más potente
            tr_wifiscan = f[0];
        } else {
            // Primera vez que aparece SSID en lista
            tr_wifiscan = wifipane.data['wifiscan-template'].cloneNode(true);
            tr_wifiscan.data = {};
            for (var k in net) {
                if (['bssid', 'channel', 'rssi'].indexOf(k) == -1) tr_wifiscan.data[k] = net[k];
            }
            tr_wifiscan.data['ap'] = [];
            tbody_wifiscan.appendChild(tr_wifiscan);
        }
        delete f;
        tr_wifiscan.data['ap'].push({
            bssid:      net.bssid,
            channel:    net.channel,
            rssi:       net.rssi
        });
        var wifidata = tr_wifiscan.data;

        // Mostrar dibujo de intensidad de señal a partir de RSSI
        var res = evaluarIntensidadRedWifi(tr_wifiscan.querySelector('td#rssi > svg.wifipower'), wifidata.ap[0].rssi);
        tr_wifiscan.querySelector('td#rssi').title = 'Intensidad de señal: '+res.pwr+' %';

        // Verificar si se está mostrando la red activa en el diálogo
        if (ssid_visible != null && ssid_visible == wifidata.ssid) {
            if (max_rssi == null || max_rssi < wifidata.ap[0].rssi) max_rssi = wifidata.ap[0].rssi;
        }

        // Mostrar estado de conexión y si hay credenciales guardadas
        tr_wifiscan.querySelector('td#ssid').textContent = wifidata.ssid;
        var connlabel = null;
        if (wifidata.connected) {
            connlabel = 'Conectado';
            tr_wifiscan.classList.add('table-success');
        } else if (wifidata.connfail) {
            connlabel = 'Ha fallado la conexión';
            tr_wifiscan.classList.add('table-danger');
        } else if (wifidata.saved) {
            // Si hay credenciales guardadas se muestra que existen
            connlabel = 'Guardada';
        }
        if (connlabel != null) {
            let sm_connlabel = document.createElement('small');
            sm_connlabel.classList.add('form-text', 'text-muted');
            sm_connlabel.textContent = connlabel;
            tr_wifiscan.querySelector('td#ssid').appendChild(sm_connlabel);
        }

        // Mostrar candado según si hay o no autenticación para la red
        tr_wifiscan.querySelector('td#auth').title =
            'Seguridad: ' + wifiauth_desc(wifidata.authmode);
        tr_wifiscan.querySelector('td#auth > svg.wifiauth > path.'+(wifidata.authmode != 0 ? 'locked' : 'unlocked'))
            .style.display = '';

        tr_wifiscan.data = wifidata;
    });

    // Verificar si se está mostrando la red activa en el diálogo
    if (ssid_visible != null && max_rssi != null) {
        var res = evaluarIntensidadRedWifi(dlg_wifiinfo.querySelector('tr#rssi > td > svg.wifipower'), max_rssi);
        dlg_wifiinfo.querySelector('tr#rssi > td.text-muted').textContent = (res.diag + ' ('+res.pwr+' %)');
    }
}

function evaluarIntensidadRedWifi(svg_wifi, rssi)
{
    var diagnostico;
    var barclass;
    var pwr = rssi2signalpercent(rssi);
    if (pwr >= 80) {
        barclass = 'at-least-4bars';
        diagnostico = 'Excelente';
    } else if (pwr >= 60) {
        barclass = 'at-least-3bars';
        diagnostico = 'Buena';
    } else if (pwr >= 40) {
        barclass = 'at-least-2bars';
        diagnostico = 'Regular';
    } else if (pwr >= 20) {
        barclass = 'at-least-1bar';
        diagnostico = 'Débil';
    } else {
        diagnostico = 'Nula';
    }
    svg_wifi.classList.remove('at-least-1bar', 'at-least-2bars', 'at-least-3bars', 'at-least-4bars');
    svg_wifi.classList.add(barclass);

    return { pwr: pwr, diag: diagnostico };
}

function mostrarReintentoScanWifi(msg)
{
    if (!yuboxWiFi_isTabActive()) {
        // El tab de WIFI ya no está visible, no se hace nada
        return;
    }

    const dv = document.createElement('div');
    dv.classList.add('clearfix');

    const spn = document.createElement('span');
    spn.classList.add('float-left');
    spn.textContent = msg;
    dv.appendChild(spn);

    const btn = document.createElement('button');
    btn.classList.add('btn', 'btn-primary', 'float-right');
    btn.textContent = 'Reintentar';
    dv.appendChild(btn);

    const al = yuboxUnwrapJQ(yuboxMostrarAlert('danger', dv));

    btn.addEventListener('click', function () {
        if (al.parentNode !== null) al.parentNode.removeChild(al);
        yuboxWiFi_setupWiFiScanListener();
    });
}

function wifiauth_desc(authmode)
{
    var desc_authmode = [
        '(ninguna)',
        'WEP',
        'WPA-PSK',
        'WPA2-PSK',
        'WPA-WPA2-PSK',
        'WPA2-ENTERPRISE'
    ];

    return (authmode >= 0 && authmode < desc_authmode.length)
        ? desc_authmode[authmode]
        : '(desconocida)';
}

function rssi2signalpercent(rssi)
{
    // El YUBOX ha reportado hasta ahora valores de RSSI de entre -100 hasta 0.
    // Se usa esto para calcular el porcentaje de fuerza de señal
    if (rssi > 0) rssi = 0;
    if (rssi < -100) rssi = -100;
    return rssi + 100;
}

function marcarRedDesconectandose(ssid)
{
    const wifipane = getYuboxPane('wifi', true);
    const tr_connected = wifipane.querySelector('table#wifiscan > tbody > tr.table-success');
    if (tr_connected == null) return;
    if (ssid != null && tr_connected.data['ssid'] != ssid) return;

    tr_connected.classList.remove('table-success');
    tr_connected.classList.add('table-warning');
    tr_connected.querySelector('td#ssid > small.text-muted').textContent = 'Desconectándose';
}

function setupNTPConfTab()
{
    const ntppane = getYuboxPane('ntpconfig', true);
    var data = {
        yuboxoffset: null,  // Offset desde hora actual a hora YUBOX, en msec
        clocktimer: null
    };
    ntppane.data = data;

    // Llenar los select con valores para elegir zona horaria
    const sel_tzh = ntppane.querySelector('select#ntptz_hh');
    const sel_tzm = ntppane.querySelector('select#ntptz_mm');
    for (var i = -12; i <= 14; i++) {
        let opt = document.createElement('option');
        opt.value = i;
        opt.textContent = ((i >= 0) ? '+' : '-')+(("0"+Math.abs(i)).slice(-2));
        sel_tzh.appendChild(opt);
    }
    for (var i = 0; i < 60; i++) {
        let opt = document.createElement('option');
        opt.value = i;
        opt.textContent = ("0"+Math.abs(i)).slice(-2);
        sel_tzm.appendChild(opt);
    }
    ntppane.querySelector('button[name=apply]').addEventListener('click', function () {
        const ntppane = getYuboxPane('ntpconfig', true);
        const sel_tzh = ntppane.querySelector('select#ntptz_hh');
        const sel_tzm = ntppane.querySelector('select#ntptz_mm');
    
        var postData = {
            ntphost:    ntppane.querySelector('form input#ntphost').value,
            ntptz:      parseInt(sel_tzh.value) * 3600
        };
        postData.ntptz += ((postData.ntptz >= 0) ? 1 : -1) * parseInt(sel_tzm.value) * 60;

        yuboxFetch('ntpconfig', 'conf.json', postData)
        .then((r) => {
            if (r.success) {
                yuboxMostrarAlertText('success', r.msg, 3000);

                // Recargar luego de 5 segundos para verificar que la conexión
                // realmente se puede realizar.
                setTimeout(yuboxLoadNTPConfig, 5 * 1000);
            } else {
                yuboxMostrarAlertText('danger', r.msg);
            }
        }, (e) => { yuboxStdAjaxFailHandler(e, 2000); });
    });
    ntppane.querySelector('button[name=browsertime]').addEventListener('click', function () {
        const ntppane = getYuboxPane('ntpconfig', true);

        let postData = {
            utctime_ms: Date.now()
        };

        yuboxFetch('ntpconfig', 'rtc.json', postData)
        .then((r) => {
            if (r.success) {
                yuboxMostrarAlertText('success', r.msg, 3000);

                // Recargar luego de 5 segundos para verificar la hora
                setTimeout(yuboxLoadNTPConfig, 5 * 1000);
            } else {
                yuboxMostrarAlertText('danger', r.msg);
            }
        }, (e) => { yuboxStdAjaxFailHandler(e, 2000); });
    });

    ntppane.data['clocktimer'] = setInterval(() => {
        const ntppane = getYuboxPane('ntpconfig', true);
        let datetext = (ntppane.data['yuboxoffset'] == null)
            ? '(no disponible)'
            : (new Date(Date.now() + ntppane.data['yuboxoffset'])).toString();
        ntppane.querySelector('form span#utctime').textContent = datetext;
    }, 500);

    // https://getbootstrap.com/docs/4.4/components/navs/#events
    getYuboxNavTab('ntpconfig')
    .on('shown.bs.tab', function (e) {
        yuboxLoadNTPConfig();
    });
}

function yuboxLoadNTPConfig()
{
    const ntppane = getYuboxPane('ntpconfig', true);
    const span_connstatus = ntppane.querySelector('form span#ntp_connstatus');
    const span_timestamp = ntppane.querySelector('form span#ntp_timestamp');

    span_connstatus.classList.remove('badge-success', 'badge-danger');
    span_connstatus.classList.add('badge-secondary');
    span_connstatus.textContent = '(consultando)';
    span_timestamp.textContent = '...';

    yuboxFetch('ntpconfig', 'conf.json')
    .then((data) => {
        // Cantidad de milisegundos a sumar a timestamp browser para obtener timestamp
        // en el dispositivo. Esto asume que no hay desvíos de reloj RTC.
        ntppane.data['yuboxoffset'] = data.utctime * 1000 - Date.now();

        span_connstatus.classList.remove('badge-danger', 'badge-success', 'badge-secondary');
        span_timestamp.textContent = '';
        if (data.ntpsync) {
            span_connstatus.classList.add('badge-success');
            span_connstatus.textContent = 'SINCRONIZADO';

            // Cálculo de fecha de última sincronización NTP dispositivo
            const date_lastsync = new Date(Date.now() - data.ntpsync_msec);
            span_timestamp.textContent = 'Últ. sinc. NTP: '
                + date_lastsync.toString();
        } else {
            span_connstatus.classList.add('badge-danger');
            span_connstatus.textContent = 'NO SINCRONIZADO';
            span_timestamp.textContent = 'No se ha contactado a servidor NTP';
        }

        ntppane.querySelector('form input#ntphost').value = data.ntphost;

        ntppane.querySelector('select#ntptz_hh').value = (Math.trunc(data.ntptz / 3600));
        ntppane.querySelector('select#ntptz_mm').value = (Math.trunc(Math.abs((data.ntptz % 3600) / 60)));
    }, (e) => {
        span_connstatus.classList.remove('badge-danger', 'badge-success', 'badge-secondary');
        span_connstatus.classList.add('badge-danger');
        span_connstatus.textContent = 'NO SINCRONIZADO';
        span_timestamp.textContent = '(error en consulta)';

        yuboxStdAjaxFailHandler(e, 2000);
    });
}
function setupMqttTab()
{
    const mqttpane = getYuboxPane('mqtt', true);

    let mqttauth_click_cb = function() {
        const div_mqttauth = mqttpane.querySelector('form div.mqttauth');
        const div_mqttauth_inputs = mqttpane.querySelectorAll('form div.mqttauth input');
        const nstat = mqttpane.querySelector('input[name=mqttauth]:checked').value;
        if (nstat == 'on') {
            div_mqttauth.style.display = '';
            div_mqttauth_inputs.forEach((elem) => { elem.required = true; });
        } else {
            div_mqttauth.style.display = 'none';
            div_mqttauth_inputs.forEach((elem) => { elem.required = false; });
        }
    };
    mqttpane.querySelectorAll('input[name=mqttauth]')
        .forEach(el => { el.addEventListener('click', mqttauth_click_cb) });
    mqttpane.querySelector('button[name=apply]').addEventListener('click', function () {
        var postData = {
            host:           mqttpane.querySelector('input#mqtthost').value,
            port:           mqttpane.querySelector('input#mqttport').value,
            tls_verifylevel:mqttpane.querySelector('input[name=tls_verifylevel]:checked').value
        };
        if (mqttpane.querySelector('input[name=mqttauth]:checked').value == 'on') {
            postData.user = mqttpane.querySelector('input#mqttuser').value;
            postData.pass = mqttpane.querySelector('input#mqttpass').value;
        }
        yuboxFetch('mqtt', 'conf.json', postData)
        .then((r) => {
            if (r.success) {
                // Recargar los datos recién guardados del dispositivo
                yuboxMostrarAlertText('success', r.msg, 3000);

                // Recargar luego de 5 segundos para verificar que la conexión
                // realmente se puede realizar.
                setTimeout(yuboxLoadMqttConfig, 5 * 1000);
            } else {
                yuboxMostrarAlertText('danger', r.msg);
            }
        }, (e) => { yuboxStdAjaxFailHandler(e, 2000); });
    });
    mqttpane.querySelectorAll('input[type=file].custom-file-input').forEach((elem) => {
        elem.addEventListener('change', function (ev) {
            const lbl = ev.target.nextElementSibling;
            if (lbl.data == undefined) lbl.data = {};
            if (lbl.data['default'] == undefined) {
                // Almacenar texto original para restaurar si archivo vacío
                lbl.data['default'] = lbl.textContent;
            }
            lbl.textContent = (ev.target.files.length > 0) ? ev.target.files[0].name : lbl.data['default'];
        })
    });
    mqttpane.querySelector('button[name=tls_servercert_upload]').addEventListener('click', function() {
        yuboxUploadMQTTCerts('tls_servercert', ['tls_servercert']);
    });
    mqttpane.querySelector('button[name=tls_clientcert_upload]').addEventListener('click', function() {
        yuboxUploadMQTTCerts('tls_clientcert', ['tls_clientcert', 'tls_clientkey']);
    });

    // https://getbootstrap.com/docs/4.4/components/navs/#events
    getYuboxNavTab('mqtt')
    .on('shown.bs.tab', function (e) {
        yuboxLoadMqttConfig();
    });
}

function yuboxLoadMqttConfig_connstatus(badgeclass, msg)
{
    const mqttpane = getYuboxPane('mqtt', true);
    const span_connstatus = mqttpane.querySelector('form span#mqtt_connstatus');

    span_connstatus.classList.remove('badge-danger', 'badge-success', 'badge-secondary');
    span_connstatus.classList.add(badgeclass);
    span_connstatus.textContent = msg;
}

function yuboxLoadMqttConfig()
{
    const mqttpane = getYuboxPane('mqtt', true);
    const span_reason = mqttpane.querySelector('form span#mqtt_disconnected_reason');
    span_reason.textContent = '...';

    yuboxLoadMqttConfig_connstatus('badge-secondary', '(consultando)');
    yuboxFetch('mqtt', 'conf.json')
    .then((data) => {
        mqttpane.querySelector('form span#mqtt_clientid').textContent = data.clientid;
        const span_tls_capable = mqttpane.querySelector('form span#tls_capable');
        span_tls_capable.classList.remove('badge-success', 'badge-secondary');
        if (data.tls_capable) {
            span_tls_capable.classList.add('badge-success')
            span_tls_capable.textContent = 'PRESENTE';
        } else {
            span_tls_capable.classList.add('badge-secondary')
            span_tls_capable.textContent = 'AUSENTE';
        }

        span_reason.textContent = '';
        if (data.connected) {
            yuboxLoadMqttConfig_connstatus('badge-success', 'CONECTADO');
        } else if (!data.want2connect) {
            yuboxLoadMqttConfig_connstatus('badge-secondary', 'NO REQUERIDO');
        } else {
            yuboxLoadMqttConfig_connstatus('badge-danger', 'DESCONECTADO');
            const reasonmsg = [
                'Desconectado a nivel de red',
                'Versión de protocolo MQTT incompatible',
                'Identificador rechazado',
                'Servidor no disponible',
                'Credenciales mal formadas',
                'No autorizado',
                'No hay memoria suficiente',
                'Huella TLS incorrecta'
            ];
            span_reason.textContent = (data.disconnected_reason >= reasonmsg.length) ? '???' : reasonmsg[data.disconnected_reason];
        }

        mqttpane.querySelector('form input#mqtthost').value = data.host;
        mqttpane.querySelector('form input#mqttport').value = data.port;
        if (data.user != null) {
            mqttpane.querySelector('form input#mqttuser').value = data.user;
            mqttpane.querySelector('form input#mqttpass').value = data.pass;
            mqttpane.querySelector('input[name=mqttauth]#on').click();
        } else {
            mqttpane.querySelector('form input#mqttuser').value = '';
            mqttpane.querySelector('form input#mqttpass').value = '';
            mqttpane.querySelector('input[name=mqttauth]#off').click();
        }

        const div_mqtt_tls = mqttpane.querySelectorAll('div.mqtt-tls');
        // Nivel de soporte TLS deseado
        mqttpane.querySelector('input[name=tls_verifylevel]#tls_verifylevel_'+data.tls_verifylevel).click();

        // Archivos de certificados presentes en servidor
        const span_tls_servercert_present = mqttpane.querySelector('form span#tls_servercert_present');
        span_tls_servercert_present.classList.remove('badge-warning', 'badge-success');
        span_tls_servercert_present.classList.add(data.tls_servercert ? 'badge-success' : 'badge-warning');
        span_tls_servercert_present.textContent = (data.tls_servercert ? 'SÍ' : 'NO');
        const span_tls_clientcert_present = mqttpane.querySelector('form span#tls_clientcert_present');
        span_tls_clientcert_present.classList.remove('badge-warning', 'badge-success')
        span_tls_clientcert_present.classList.add(data.tls_clientcert ? 'badge-success' : 'badge-warning');
        span_tls_clientcert_present.textContent = (data.tls_clientcert ? 'SÍ' : 'NO');
        if (data.tls_capable) {
            // Hay soporte TLS
            div_mqtt_tls.forEach((div) => { div.style.display = ''; });
        } else {
            // No hay soporte TLS
            div_mqtt_tls.forEach((div) => { div.style.display = 'none'; });
        }
    }, (e) => { yuboxStdAjaxFailHandler(e, 2000); });
}

function yuboxUploadMQTTCerts(route_upload, filelist)
{
    const mqttpane = getYuboxPane('mqtt', true);

    if (typeof FormData == 'undefined') {
        yuboxMostrarAlertText('danger', 'Este navegador no soporta FormData para subida de datos. Actualice su navegador.', 2000);
        return;
    }
    var postData = new FormData();

    for (let k of filelist) {
        let fi = mqttpane.querySelector('input[type=file]#'+k);
        if (fi.files.length <= 0) {
            yuboxMostrarAlertText('danger', 'Es necesario elegir un archivo de certificado: '+k, 2000);
            return;
        }
        postData.append(k, fi.files[0]);
    }
    yuboxFetch('mqtt', route_upload, postData)
    .then((data) => {
        if (data.success) {
            // Al aplicar actualización debería recargarse más tarde
            yuboxMostrarAlertText('success', data.msg, 5000);
            setTimeout(function () {
                yuboxLoadMqttConfig();
            }, 5 * 1000);
        } else {
            yuboxMostrarAlertText('danger', data.msg, 6000);
        }
    }, (e) => { yuboxStdAjaxFailHandler(e, 5000); });
}
function setupWebAuthTab()
{
    const authpane = getYuboxPane('webauth', true);

    // https://getbootstrap.com/docs/4.4/components/navs/#events
    getYuboxNavTab('webauth').on('shown.bs.tab', function (e) {
        yuboxFetch('authconfig')
        .then((data) => {
            authpane.querySelector('input#yubox_username').value = data.username;
            authpane.querySelectorAll('input#yubox_password1, input#yubox_password2')
            .forEach((yubox_password) => { yubox_password.value = data.password; });
        }, (e) => { yuboxStdAjaxFailHandler(e, 2000); });
    });
    authpane.querySelector('button[name=apply]').addEventListener('click', function () {
        var postData = {
            password1: authpane.querySelector('input#yubox_password1').value,
            password2: authpane.querySelector('input#yubox_password2').value
        };
        if (postData.password1 != postData.password2) {
            yuboxMostrarAlertText('danger', 'Contraseña y confirmación no coinciden.', 5000);
        } else if (postData.password1 == '') {
            yuboxMostrarAlertText('danger', 'Contraseña no puede estar vacía.', 5000);
        } else {
            yuboxFetch('authconfig', '', postData)
            .then((data) => {
                if (data.success) {
                    // Al guardar correctamente las credenciales, recargar para que las pida
                    yuboxMostrarAlertText('success', data.msg, 2000);
                    setTimeout(function () {
                        window.location.reload();
                    }, 3 * 1000);
                } else {
                    yuboxMostrarAlertText('danger', data.msg, 2000);
                }
            }, (e) => { yuboxStdAjaxFailHandler(e, 2000); })
        }
    });
}

function setupYuboxOTATab()
{
    const otapane = getYuboxPane('yuboxOTA', true);
    var data = {
        'sse':  null
    };
    otapane.data = data;

    // https://getbootstrap.com/docs/4.4/components/navs/#events
    getYuboxNavTab('yuboxOTA').on('shown.bs.tab', function (e) {
        // Si el control select de la lista de firmwares está DESACTIVADO,
        // se asume que esta sesión todavía está subiendo algo al equipo.
        if (otapane.querySelector('select#yuboxfirmwarelist').disabled) {
            return;
        }

        yuboxFetch('yuboxOTA', 'firmwarelist.json')
        .then((data) => {
            const sel_firmwarelist = otapane.querySelector('select#yuboxfirmwarelist');
            while (sel_firmwarelist.firstChild) sel_firmwarelist.removeChild(sel_firmwarelist.firstChild);
            for (var i = 0; i < data.length; i++) {
                let opt = document.createElement('option');
                opt.value = data[i].tag;
                opt.textContent = data[i].desc;
                opt.data = data[i];
                sel_firmwarelist.appendChild(opt);
            }
            sel_firmwarelist.value = data[0].tag;
            sel_firmwarelist.dispatchEvent(new Event('change'));
        }, (e) => { yuboxStdAjaxFailHandler(e, 2000); });
    });

    otapane.querySelector('select#yuboxfirmwarelist').addEventListener('change', function() {
        const opt = this.querySelector('option[value='+this.value+']');
        otapane.querySelectorAll('span.yubox-firmware-desc').forEach((elem) => { elem.textContent = opt.data['desc']; });

        yuboxFetchURL(opt.data['rollback'])
        .then((data) => {
            const spanRB = otapane.querySelector('span#canrollback');
            const btnRB = otapane.querySelector('button[name="rollback"]');

            spanRB.classList.remove('badge-danger', 'badge-success');
            if (data.canrollback) {
                spanRB.classList.add('badge-success');
                spanRB.textContent = 'RESTAURABLE';
                btnRB.disabled = false;
            } else {
                spanRB.classList.add('badge-danger');
                spanRB.textContent = 'NO RESTAURABLE';
                btnRB.disabled = true;
            }
        }, (e) => { yuboxStdAjaxFailHandler(e, 5000); });
    });

    otapane.querySelector('input[type=file]#tgzupload').addEventListener('change', function (ev) {
        const lbl = ev.target.nextElementSibling;
        if (lbl.data == undefined) lbl.data = {};
        if (lbl.data['default'] == undefined) {
            // Almacenar texto original para restaurar si archivo vacío
            lbl.data['default'] = lbl.textContent;
        }
        lbl.textContent = (ev.target.files.length > 0) ? ev.target.files[0].name : lbl.data['default'];
    });
    otapane.querySelector('button[name=apply]').addEventListener('click', function () {
        const sel_firmwarelist = otapane.querySelector('select#yuboxfirmwarelist');
        const route_tgzupload = sel_firmwarelist.querySelector('option[value='+sel_firmwarelist.value+']').data['tgzupload'];

        var fi = otapane.querySelector('input[type=file]#tgzupload');
        if (fi.files.length <= 0) {
            yuboxMostrarAlertText('danger', 'Es necesario elegir un archivo tgz para actualización.', 2000);
            return;
        }
        if (typeof FormData == 'undefined') {
            yuboxMostrarAlertText('danger', 'Este navegador no soporta FormData para subida de datos. Actualice su navegador.', 2000);
            return;
        }
        var postData = new FormData();
        postData.append('tgzupload', fi.files[0]);
        yuboxOTAUpload_init();
        yuboxFetchURL(route_tgzupload, postData)
        .then((data) => {
            if (data.success) {
                // Al aplicar actualización debería recargarse más tarde
                yuboxMostrarAlertText('success', data.msg, 5000);
                setTimeout(function () {
                    window.location.reload();
                }, 10 * 1000);

                if (data.reboot) {
                    // Por haber recibido esta indicación, ya se sabe que el
                    // dispositivo está listo para ser reiniciado.
                    yuboxFetch('yuboxOTA', 'reboot', {})
                    .catch((e) => { yuboxStdAjaxFailHandler(e, 5000); })
                }
            } else {
                yuboxMostrarAlertText('danger', data.msg, 6000);
            }
            yuboxOTAUpload_shutdown();
        }, (e) => {
            yuboxStdAjaxFailHandler(e, 5000);
            yuboxOTAUpload_shutdown();
        });
    });
    otapane.querySelector('button[name=rollback]').addEventListener('click', function () {
        const sel_firmwarelist = otapane.querySelector('select#yuboxfirmwarelist');
        const route_rollback = sel_firmwarelist.querySelector('option[value='+sel_firmwarelist.value+']').data['rollback'];

        yuboxOTAUpload_setDisableBtns(true);
        yuboxFetchURL(route_rollback, {})
        .then((data) => {
            if (data.success) {
                // Al aplicar actualización debería recargarse más tarde
                yuboxMostrarAlertText('success', data.msg, 4000);
                setTimeout(function () {
                    window.location.reload();
                }, 10 * 1000);
            } else {
                yuboxMostrarAlertText('danger', data.msg, 2000);
            }
            yuboxOTAUpload_setDisableBtns(false);
        }, (e) => {
            yuboxStdAjaxFailHandler(e, 5000);
            yuboxOTAUpload_setDisableBtns(false);
        });
    });
    otapane.querySelector('button[name=reboot]').addEventListener('click', function () {
        yuboxOTAUpload_setDisableBtns(true);
        yuboxFetch('yuboxOTA', 'reboot', {})
        .then((data) => {
            if (data.success) {
                // Al aplicar actualización debería recargarse más tarde
                yuboxMostrarAlertText('success', data.msg, 4000);
                setTimeout(function () {
                    window.location.reload();
                }, 10 * 1000);
            } else {
                yuboxMostrarAlertText('danger', data.msg, 2000);
            }
            yuboxOTAUpload_setDisableBtns(false);
        }, (e) => {
            yuboxStdAjaxFailHandler(e, 5000);
            yuboxOTAUpload_setDisableBtns(false);
        });
    });

    // Diálogo modal de reporte de hardware
    otapane.querySelector('button[name=hwreport]').addEventListener('click', function () {
        yuboxFetch('yuboxOTA', 'hwreport.json')
        .then((data) => {
            const dlg_hwinfo = otapane.querySelector('div#hwreport');
            const hwtable = dlg_hwinfo.querySelector('table#hwinfo > tbody');

            // Formatos especiales para algunos campos
            data.ARDUINO_ESP32_GIT_VER = data.ARDUINO_ESP32_GIT_VER.toString(16);
            data.EFUSE_MAC = data.EFUSE_MAC.toString(16);
            data.CPU_MHZ = data.CPU_MHZ + ' MHz';
            data.FLASH_SPEED = (data.FLASH_SPEED / 1000000) + ' MHz';

            for (const key in data) {
                hwtable.querySelector('tr#'+key+' > td.text-muted').textContent = data[key];
            }

            // Diálogo modal Bootstrap 4 requiere jQuery
            $(dlg_hwinfo).modal({ focus: true });
        }, (e) => { yuboxStdAjaxFailHandler(e, 2000); });
    });
}

function yuboxOTAUpload_init()
{
    yuboxOTAUpload_setDisableBtns(true);

    const otapane = getYuboxPane('yuboxOTA', true);
    yuboxOTAUpload_setProgressBar(0);
    yuboxOTAUpload_fileProgress('-', '0', '0', '0');
    otapane.querySelectorAll('div.upload-progress').forEach((elem) => { elem.style.display = ''; });

    if (!!window.EventSource) {
        var sse = new EventSource(yuboxAPI('yuboxOTA')+'/events');
        sse.addEventListener('uploadFileStart', function (e) {
            var data = JSON.parse(e.data);
            var totalKB = data.total / 1024.0;
            var currUploadKB = data.currupload / 1024.0;
            yuboxOTAUpload_fileProgress(data.filename, 0, totalKB.toFixed(1), currUploadKB.toFixed(1));
            const pb = otapane.querySelector('div.progress-bar');
            pb.classList.remove('bg-info', 'bg-danger');
            pb.classList.add(data.firmware ? 'bg-danger' : 'bg-info');
            yuboxOTAUpload_setProgressBar(0);
        });
        sse.addEventListener('uploadFileProgress', function (e) {
            var data = JSON.parse(e.data);
            var totalKB = data.total / 1024.0;
            var currKB = data.current / 1024.0;
            var currUploadKB = data.currupload / 1024.0;
            yuboxOTAUpload_fileProgress(data.filename, currKB.toFixed(1), totalKB.toFixed(1), currUploadKB.toFixed(1));
            yuboxOTAUpload_setProgressBar(totalKB > 0.0 ? 100.0 * currKB / totalKB : 0);
        });
        sse.addEventListener('uploadFileEnd', function (e) {
            var data = JSON.parse(e.data);
            var totalKB = data.total / 1024.0;
            var currUploadKB = data.currupload / 1024.0;
            yuboxOTAUpload_fileProgress(data.filename, totalKB.toFixed(1), totalKB.toFixed(1), currUploadKB.toFixed(1));
            yuboxOTAUpload_setProgressBar(100);
        });
        sse.addEventListener('uploadPostTask', function (e) {
            var data = JSON.parse(e.data);
            var msg = data.task;
            var taskDesc = {
                'firmware-commit-start':        'Iniciando commit de firmware nuevo',
                'firmware-commit-failed':       'Falló el commit de firmware nuevo',
                'firmware-commit-end':          'Finalizado commit de firmware nuevo',
                'datafiles-load-oldmanifest':   'Cargando lista de archivos de datos viejos',
                'datafiles-delete-oldbackup':   'Borrando respaldo anterior de archivos de datos',
                'datafiles-rename-oldfiles':    'Respaldando archivos de datos viejos',
                'datafiles-rename-newfiles':    'Instalando archivos de datos nuevos',
                'datafiles-end':                'Fin de instalación de archivos de datos'
            };
            if (taskDesc[data.task] != undefined) msg = taskDesc[data.task];
            yuboxOTAUpload_setProgressBarMessage(100, msg);
        });
        otapane.data['sse'] = sse;
    } else {
      yuboxMostrarAlertText('danger', 'Este navegador no soporta Server-Sent Events, no se puede monitorear upload.');
    }
}

function yuboxOTAUpload_fileProgress(f, c, t, u)
{
    const otapane = getYuboxPane('yuboxOTA', true);
    otapane.querySelector('div.upload-progress span#filename').textContent = f;
    otapane.querySelector('div.upload-progress span#current').textContent = c;
    otapane.querySelector('div.upload-progress span#total').textContent = t;
    otapane.querySelector('div.upload-progress span#currupload').textContent = u;
}

function yuboxOTAUpload_shutdown()
{
    yuboxOTAUpload_setDisableBtns(false);
    const otapane = getYuboxPane('yuboxOTA', true);
    otapane.querySelectorAll('div.upload-progress').forEach((elem) => { elem.style.display = 'none'; });
    if (otapane.data['sse'] != null) {
        otapane.data['sse'].close();
        otapane.data['sse'] = null;
    }
}

function yuboxOTAUpload_setDisableBtns(v)
{
    getYuboxPane('yuboxOTA', true)
    .querySelectorAll('button[name=apply], button[name=rollback], button[name=reboot], select#yuboxfirmwarelist')
    .forEach((elem) => { elem.disabled = v; });
}

function yuboxOTAUpload_setProgressBar(v)
{
    yuboxOTAUpload_setProgressBarMessage(v, v.toFixed(1) + ' %');
}

function yuboxOTAUpload_setProgressBarMessage(v, msg)
{
    const otapane = getYuboxPane('yuboxOTA', true);
    const pb = otapane.querySelector('div.progress-bar');
    pb.style.width = v+'%';
    pb.attributes['aria-valuenow'] = v;
    pb.textContent = msg;
}


function yuboxAPI(s)
{
    var mockup =  window.location.pathname.startsWith('/yubox-mockup/');
    return mockup
        ? '/yubox-mockup/'+s+'.php'
        : '/yubox-api/'+s;
}

function yuboxMostrarAlertText(alertstyle, text, timeout)
{
    const content = document.createElement('span');
    content.textContent = text;
    return yuboxMostrarAlert(alertstyle, content, timeout);
}

function yuboxMostrarAlert(alertstyle, content, timeout)
{
    return yuboxDlgMostrarAlert('main > div.container', alertstyle, content, timeout);
}

function yuboxDlgMostrarAlertText(basesel, alertstyle, text, timeout)
{
    const content = document.createElement('span');
    content.textContent = text;
    return yuboxDlgMostrarAlert(basesel, alertstyle, content, timeout);
}

function yuboxDlgMostrarAlert(basesel, alertstyle, content, timeout)
{
    basesel = yuboxUnwrapJQ(basesel);
    if (typeof basesel == 'string') basesel = document.querySelector(basesel);

    // Buscar plantilla de mensaje alerta, clonar y preparar con estilo
    const tpl_al = basesel.querySelector('div.alert.yubox-alert-template');
    const al = tpl_al.cloneNode(true);
    al.classList.remove('yubox-alert-template');
    al.classList.add('yubox-alert');
    al.classList.add('alert-'+alertstyle);

    // Insertar contenido DOM que es texto del mensaje
    content = yuboxUnwrapJQ(content);
    al.querySelector('button.close').insertAdjacentElement('beforebegin', content);

    // Quitar cualquier alarma vieja, insertar la nueva
    const old_al = basesel.querySelector('div.yubox-alert');
    if (old_al != null && old_al.parentNode !== null) old_al.parentNode.removeChild(old_al);
    tpl_al.insertAdjacentElement('afterend', al);

    // Quitar mensaje de alarma luego de timeout
    if (timeout != undefined) {
        setTimeout(function() {
            if (al.parentNode !== null) al.parentNode.removeChild(al);
        }, timeout);
    }

    return yuboxWrapJQ(al);
}

function yuboxStdAjaxFailHandler(e, timeout)
{
    yuboxStdAjaxFailHandlerDlg('main > div.container', e, timeout);
}

function yuboxStdAjaxFailHandlerDlg(basesel, e, timeout)
{
    var msg;
    if (e.status == 0) {
        msg = 'Fallo al contactar dispositivo';
    } else if (e.responseJSON == undefined) {
        msg = 'Tipo de contenido inesperado en respuesta';
    } else {
        msg = e.responseJSON.msg;
    }
    yuboxDlgMostrarAlertText(basesel, 'danger', msg, timeout);
}

function getYuboxPane(modname, raw = false)
{
    let dom = document.querySelector('div#yuboxMainTabContent > div.tab-pane#'+modname);
    return raw ? dom : yuboxWrapJQ(dom);
}
function getYuboxNavTab(modname, raw = false)
{
    let dom = document.querySelector('ul#yuboxMainTab a#'+modname+'-tab[data-toggle="tab"]');
    return raw ? dom : yuboxWrapJQ(dom);
}

function yuboxFetch(module, rsrc = '', postData = null)
{
    let method = (postData == null) ? 'GET' : 'POST';
    return yuboxFetchMethod(method, module, rsrc, postData);
}

function yuboxFetchURL(url, postData = null)
{
    let method = (postData == null) ? 'GET' : 'POST';
    return yuboxFetchMethodURL(method, url, postData);
}

function yuboxFetchMethod(method, module, rsrc = '', postData = null)
{
    let url = yuboxAPI(module);
    if (rsrc != '') url += '/' + rsrc;

    return yuboxFetchMethodURL(method, url, postData);
}

function yuboxFetchMethodURL(method, url, postData = null)
{
    // Decidir Content-Type
    if (postData != null) {
        if (postData instanceof FormData) {
        } else if (postData instanceof URLSearchParams) {
        } else {
            // Se asume objeto ordinario
            postData = new URLSearchParams(postData);
        }
    }

    let init = {
        method: method
    };
    if (postData != null) init['body'] = postData;
    return fetch(url, init)
    .then(response => {
        let p;

        if (response.status == 204) {
            // Voy a asumir que realmente no hay más contenido
            p = Promise.resolve(null);
        } else {
            let ct = response.headers.get('content-type');
            if (ct.toLowerCase().indexOf('application/json') == 0)
                p = response.json();
            else if (ct.toLowerCase().indexOf('text/plain') == 0)
                p =  response.text();
            else if (ct.toLowerCase().indexOf('text/html') == 0)
                p = response.text(); // TODO: parseo?
            else
                p = response.blob(); // ¿Es esto lo más útil?
        }
        return p
        .then(data => {
            if (!response.ok) {
                let e = new Error(response.statusText, { cause: response });
                e.responseJSON = data;
                throw e;
            }
            return data;
        });
    });
}

// Las siguientes dos funciones envuelven un DOM pelado en jQuery, y lo extraen
// de un objeto jQuery, si jQuery está presente. De lo contrario, no hacen nada.
function yuboxWrapJQ(domobj)
{
    if (typeof jQuery == 'undefined') return domobj;
    return $(domobj);
}
function yuboxUnwrapJQ(jqobj)
{
    if (typeof jQuery == 'undefined') return jqobj;
    if (!(jqobj instanceof jQuery)) return jqobj;
    if (jqobj.length > 0) return jqobj[0];
    return null;
}