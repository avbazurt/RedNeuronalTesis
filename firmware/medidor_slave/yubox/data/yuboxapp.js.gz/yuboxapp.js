if (document.readyState == 'loading') {
    document.addEventListener('DOMContentLoaded', yuboxSetupAllTabs);
} else {
    yuboxSetupAllTabs();
}

function yuboxSetupAllTabs()
{
    setupLectorTab();
    setupNTPConfTab();
    setupWebAuthTab();
    setupYuboxOTATab();

    // Mostrar el tab preparado por omisión como activo
    const tab = document.querySelector('ul#yuboxMainTab a.set-active');
    tab.classList.remove('set-active');
    yuboxWrapJQ(tab).tab('show');   // <-- Bootstrap 4 requiere jQuery
}

function setupLectorTab()
{
    var lectorpane = getYuboxPane('lector', true);
    var data = {
        'sse':  null,
        'chart': null,
    };
    lectorpane.data = data;

    var ctx = lectorpane.querySelector('canvas#atmospheric').getContext('2d');
    var chtData = {
        datasets:   [{
            label:  'Presión',
            borderColor: "rgb(255, 99, 132)",
            backgroundColor: "rgb(255, 99, 132)",
            fill: false,
            data: [],
            yAxisID: 'press'
        },{
            label:  'Temperatura',
            borderColor: "rgb(54, 162, 235)",
            backgroundColor: "rgb(54, 162, 235)",
            fill: false,
            data: [],
            yAxisID: 'temp'
        }]
    };
    var cht = new Chart(ctx, {
        type:       'line',
        data:       chtData,
        options:    {
            responsive: true,
            hoverMode: 'index',
            stacked: false,
            title: {
                display: true,
                text: 'Presión y temperatura'
            },
            scales: {
                xAxes:  [{
                    type:   'time'
                }],
                yAxes:  [{
                    type: 'linear',
                    display: true,
                    position: 'left',
                    id: 'press'
                },{
                    type: 'linear',
                    display: true,
                    position: 'right',
                    id: 'temp'
                }]
            }
        }
    });
    lectorpane.data['chart'] = cht;

    if (!!window.EventSource) {
        var sse = new EventSource(yuboxAPI('lectura')+'/events');
        sse.addEventListener('message', function (e) {
            var data = JSON.parse(e.data);
            yuboxLector_actualizar(new Date(data.ts), data.pressure, data.temperature);
        });
        lectorpane.data['sse'] = sse;
    }
}

function yuboxLector_actualizar(d, p, t)
{
    var lectorpane = getYuboxPane('lector', true);
    lectorpane.querySelector('h3#temp').textContent = t.toFixed(2);
    lectorpane.querySelector('h3#press').textContent = p.toFixed(2);
    var cht = lectorpane.data['chart'];
    cht.data.datasets[0].data.push({x: d, y: p});
    cht.data.datasets[1].data.push({x: d, y: t});
    if (d.valueOf() - cht.data.datasets[0].data[0].x.valueOf() > 10 * 60 * 1000) {
        cht.data.datasets[0].data.shift();
        cht.data.datasets[1].data.shift();
    }
    cht.update();
}

function setupNTPConfTab()
{
    const ntppane = getYuboxPane('ntpconfig', true);
    var data = {
        yuboxoffset: null,  // Offset desde hora actual a hora YUBOX, en msec
        clocktimer: null
    };
    ntppane.data = data;

    // Llenar los select con valores para elegir zona horaria
    const sel_tzh = ntppane.querySelector('select#ntptz_hh');
    const sel_tzm = ntppane.querySelector('select#ntptz_mm');
    for (var i = -12; i <= 14; i++) {
        let opt = document.createElement('option');
        opt.value = i;
        opt.textContent = ((i >= 0) ? '+' : '-')+(("0"+Math.abs(i)).slice(-2));
        sel_tzh.appendChild(opt);
    }
    for (var i = 0; i < 60; i++) {
        let opt = document.createElement('option');
        opt.value = i;
        opt.textContent = ("0"+Math.abs(i)).slice(-2);
        sel_tzm.appendChild(opt);
    }
    ntppane.querySelector('button[name=apply]').addEventListener('click', function () {
        const ntppane = getYuboxPane('ntpconfig', true);
        const sel_tzh = ntppane.querySelector('select#ntptz_hh');
        const sel_tzm = ntppane.querySelector('select#ntptz_mm');
    
        var postData = {
            ntphost:    ntppane.querySelector('form input#ntphost').value,
            ntptz:      parseInt(sel_tzh.value) * 3600
        };
        postData.ntptz += ((postData.ntptz >= 0) ? 1 : -1) * parseInt(sel_tzm.value) * 60;

        yuboxFetch('ntpconfig', 'conf.json', postData)
        .then((r) => {
            if (r.success) {
                yuboxMostrarAlertText('success', r.msg, 3000);

                // Recargar luego de 5 segundos para verificar que la conexión
                // realmente se puede realizar.
                setTimeout(yuboxLoadNTPConfig, 5 * 1000);
            } else {
                yuboxMostrarAlertText('danger', r.msg);
            }
        }, (e) => { yuboxStdAjaxFailHandler(e, 2000); });
    });
    ntppane.querySelector('button[name=browsertime]').addEventListener('click', function () {
        const ntppane = getYuboxPane('ntpconfig', true);

        let postData = {
            utctime_ms: Date.now()
        };

        yuboxFetch('ntpconfig', 'rtc.json', postData)
        .then((r) => {
            if (r.success) {
                yuboxMostrarAlertText('success', r.msg, 3000);

                // Recargar luego de 5 segundos para verificar la hora
                setTimeout(yuboxLoadNTPConfig, 5 * 1000);
            } else {
                yuboxMostrarAlertText('danger', r.msg);
            }
        }, (e) => { yuboxStdAjaxFailHandler(e, 2000); });
    });

    ntppane.data['clocktimer'] = setInterval(() => {
        const ntppane = getYuboxPane('ntpconfig', true);
        let datetext = (ntppane.data['yuboxoffset'] == null)
            ? '(no disponible)'
            : (new Date(Date.now() + ntppane.data['yuboxoffset'])).toString();
        ntppane.querySelector('form span#utctime').textContent = datetext;
    }, 500);

    // https://getbootstrap.com/docs/4.4/components/navs/#events
    getYuboxNavTab('ntpconfig')
    .on('shown.bs.tab', function (e) {
        yuboxLoadNTPConfig();
    });
}

function yuboxLoadNTPConfig()
{
    const ntppane = getYuboxPane('ntpconfig', true);
    const span_connstatus = ntppane.querySelector('form span#ntp_connstatus');
    const span_timestamp = ntppane.querySelector('form span#ntp_timestamp');

    span_connstatus.classList.remove('badge-success', 'badge-danger');
    span_connstatus.classList.add('badge-secondary');
    span_connstatus.textContent = '(consultando)';
    span_timestamp.textContent = '...';

    yuboxFetch('ntpconfig', 'conf.json')
    .then((data) => {
        // Cantidad de milisegundos a sumar a timestamp browser para obtener timestamp
        // en el dispositivo. Esto asume que no hay desvíos de reloj RTC.
        ntppane.data['yuboxoffset'] = data.utctime * 1000 - Date.now();

        span_connstatus.classList.remove('badge-danger', 'badge-success', 'badge-secondary');
        span_timestamp.textContent = '';
        if (data.ntpsync) {
            span_connstatus.classList.add('badge-success');
            span_connstatus.textContent = 'SINCRONIZADO';

            // Cálculo de fecha de última sincronización NTP dispositivo
            const date_lastsync = new Date(Date.now() - data.ntpsync_msec);
            span_timestamp.textContent = 'Últ. sinc. NTP: '
                + date_lastsync.toString();
        } else {
            span_connstatus.classList.add('badge-danger');
            span_connstatus.textContent = 'NO SINCRONIZADO';
            span_timestamp.textContent = 'No se ha contactado a servidor NTP';
        }

        ntppane.querySelector('form input#ntphost').value = data.ntphost;

        ntppane.querySelector('select#ntptz_hh').value = (Math.trunc(data.ntptz / 3600));
        ntppane.querySelector('select#ntptz_mm').value = (Math.trunc(Math.abs((data.ntptz % 3600) / 60)));
    }, (e) => {
        span_connstatus.classList.remove('badge-danger', 'badge-success', 'badge-secondary');
        span_connstatus.classList.add('badge-danger');
        span_connstatus.textContent = 'NO SINCRONIZADO';
        span_timestamp.textContent = '(error en consulta)';

        yuboxStdAjaxFailHandler(e, 2000);
    });
}
function setupWebAuthTab()
{
    const authpane = getYuboxPane('webauth', true);

    // https://getbootstrap.com/docs/4.4/components/navs/#events
    getYuboxNavTab('webauth').on('shown.bs.tab', function (e) {
        yuboxFetch('authconfig')
        .then((data) => {
            authpane.querySelector('input#yubox_username').value = data.username;
            authpane.querySelectorAll('input#yubox_password1, input#yubox_password2')
            .forEach((yubox_password) => { yubox_password.value = data.password; });
        }, (e) => { yuboxStdAjaxFailHandler(e, 2000); });
    });
    authpane.querySelector('button[name=apply]').addEventListener('click', function () {
        var postData = {
            password1: authpane.querySelector('input#yubox_password1').value,
            password2: authpane.querySelector('input#yubox_password2').value
        };
        if (postData.password1 != postData.password2) {
            yuboxMostrarAlertText('danger', 'Contraseña y confirmación no coinciden.', 5000);
        } else if (postData.password1 == '') {
            yuboxMostrarAlertText('danger', 'Contraseña no puede estar vacía.', 5000);
        } else {
            yuboxFetch('authconfig', '', postData)
            .then((data) => {
                if (data.success) {
                    // Al guardar correctamente las credenciales, recargar para que las pida
                    yuboxMostrarAlertText('success', data.msg, 2000);
                    setTimeout(function () {
                        window.location.reload();
                    }, 3 * 1000);
                } else {
                    yuboxMostrarAlertText('danger', data.msg, 2000);
                }
            }, (e) => { yuboxStdAjaxFailHandler(e, 2000); })
        }
    });
}

function setupYuboxOTATab()
{
    const otapane = getYuboxPane('yuboxOTA', true);
    var data = {
        'sse':  null
    };
    otapane.data = data;

    // https://getbootstrap.com/docs/4.4/components/navs/#events
    getYuboxNavTab('yuboxOTA').on('shown.bs.tab', function (e) {
        // Si el control select de la lista de firmwares está DESACTIVADO,
        // se asume que esta sesión todavía está subiendo algo al equipo.
        if (otapane.querySelector('select#yuboxfirmwarelist').disabled) {
            return;
        }

        yuboxFetch('yuboxOTA', 'firmwarelist.json')
        .then((data) => {
            const sel_firmwarelist = otapane.querySelector('select#yuboxfirmwarelist');
            while (sel_firmwarelist.firstChild) sel_firmwarelist.removeChild(sel_firmwarelist.firstChild);
            for (var i = 0; i < data.length; i++) {
                let opt = document.createElement('option');
                opt.value = data[i].tag;
                opt.textContent = data[i].desc;
                opt.data = data[i];
                sel_firmwarelist.appendChild(opt);
            }
            sel_firmwarelist.value = data[0].tag;
            sel_firmwarelist.dispatchEvent(new Event('change'));
        }, (e) => { yuboxStdAjaxFailHandler(e, 2000); });
    });

    otapane.querySelector('select#yuboxfirmwarelist').addEventListener('change', function() {
        const opt = this.querySelector('option[value='+this.value+']');
        otapane.querySelectorAll('span.yubox-firmware-desc').forEach((elem) => { elem.textContent = opt.data['desc']; });

        yuboxFetchURL(opt.data['rollback'])
        .then((data) => {
            const spanRB = otapane.querySelector('span#canrollback');
            const btnRB = otapane.querySelector('button[name="rollback"]');

            spanRB.classList.remove('badge-danger', 'badge-success');
            if (data.canrollback) {
                spanRB.classList.add('badge-success');
                spanRB.textContent = 'RESTAURABLE';
                btnRB.disabled = false;
            } else {
                spanRB.classList.add('badge-danger');
                spanRB.textContent = 'NO RESTAURABLE';
                btnRB.disabled = true;
            }
        }, (e) => { yuboxStdAjaxFailHandler(e, 5000); });
    });

    otapane.querySelector('input[type=file]#tgzupload').addEventListener('change', function (ev) {
        const lbl = ev.target.nextElementSibling;
        if (lbl.data == undefined) lbl.data = {};
        if (lbl.data['default'] == undefined) {
            // Almacenar texto original para restaurar si archivo vacío
            lbl.data['default'] = lbl.textContent;
        }
        lbl.textContent = (ev.target.files.length > 0) ? ev.target.files[0].name : lbl.data['default'];
    });
    otapane.querySelector('button[name=apply]').addEventListener('click', function () {
        const sel_firmwarelist = otapane.querySelector('select#yuboxfirmwarelist');
        const route_tgzupload = sel_firmwarelist.querySelector('option[value='+sel_firmwarelist.value+']').data['tgzupload'];

        var fi = otapane.querySelector('input[type=file]#tgzupload');
        if (fi.files.length <= 0) {
            yuboxMostrarAlertText('danger', 'Es necesario elegir un archivo tgz para actualización.', 2000);
            return;
        }
        if (typeof FormData == 'undefined') {
            yuboxMostrarAlertText('danger', 'Este navegador no soporta FormData para subida de datos. Actualice su navegador.', 2000);
            return;
        }
        var postData = new FormData();
        postData.append('tgzupload', fi.files[0]);
        yuboxOTAUpload_init();
        yuboxFetchURL(route_tgzupload, postData)
        .then((data) => {
            if (data.success) {
                // Al aplicar actualización debería recargarse más tarde
                yuboxMostrarAlertText('success', data.msg, 5000);
                setTimeout(function () {
                    window.location.reload();
                }, 10 * 1000);

                if (data.reboot) {
                    // Por haber recibido esta indicación, ya se sabe que el
                    // dispositivo está listo para ser reiniciado.
                    yuboxFetch('yuboxOTA', 'reboot', {})
                    .catch((e) => { yuboxStdAjaxFailHandler(e, 5000); })
                }
            } else {
                yuboxMostrarAlertText('danger', data.msg, 6000);
            }
            yuboxOTAUpload_shutdown();
        }, (e) => {
            yuboxStdAjaxFailHandler(e, 5000);
            yuboxOTAUpload_shutdown();
        });
    });
    otapane.querySelector('button[name=rollback]').addEventListener('click', function () {
        const sel_firmwarelist = otapane.querySelector('select#yuboxfirmwarelist');
        const route_rollback = sel_firmwarelist.querySelector('option[value='+sel_firmwarelist.value+']').data['rollback'];

        yuboxOTAUpload_setDisableBtns(true);
        yuboxFetchURL(route_rollback, {})
        .then((data) => {
            if (data.success) {
                // Al aplicar actualización debería recargarse más tarde
                yuboxMostrarAlertText('success', data.msg, 4000);
                setTimeout(function () {
                    window.location.reload();
                }, 10 * 1000);
            } else {
                yuboxMostrarAlertText('danger', data.msg, 2000);
            }
            yuboxOTAUpload_setDisableBtns(false);
        }, (e) => {
            yuboxStdAjaxFailHandler(e, 5000);
            yuboxOTAUpload_setDisableBtns(false);
        });
    });
    otapane.querySelector('button[name=reboot]').addEventListener('click', function () {
        yuboxOTAUpload_setDisableBtns(true);
        yuboxFetch('yuboxOTA', 'reboot', {})
        .then((data) => {
            if (data.success) {
                // Al aplicar actualización debería recargarse más tarde
                yuboxMostrarAlertText('success', data.msg, 4000);
                setTimeout(function () {
                    window.location.reload();
                }, 10 * 1000);
            } else {
                yuboxMostrarAlertText('danger', data.msg, 2000);
            }
            yuboxOTAUpload_setDisableBtns(false);
        }, (e) => {
            yuboxStdAjaxFailHandler(e, 5000);
            yuboxOTAUpload_setDisableBtns(false);
        });
    });

    // Diálogo modal de reporte de hardware
    otapane.querySelector('button[name=hwreport]').addEventListener('click', function () {
        yuboxFetch('yuboxOTA', 'hwreport.json')
        .then((data) => {
            const dlg_hwinfo = otapane.querySelector('div#hwreport');
            const hwtable = dlg_hwinfo.querySelector('table#hwinfo > tbody');

            // Formatos especiales para algunos campos
            data.ARDUINO_ESP32_GIT_VER = data.ARDUINO_ESP32_GIT_VER.toString(16);
            data.EFUSE_MAC = data.EFUSE_MAC.toString(16);
            data.CPU_MHZ = data.CPU_MHZ + ' MHz';
            data.FLASH_SPEED = (data.FLASH_SPEED / 1000000) + ' MHz';

            for (const key in data) {
                hwtable.querySelector('tr#'+key+' > td.text-muted').textContent = data[key];
            }

            // Diálogo modal Bootstrap 4 requiere jQuery
            $(dlg_hwinfo).modal({ focus: true });
        }, (e) => { yuboxStdAjaxFailHandler(e, 2000); });
    });
}

function yuboxOTAUpload_init()
{
    yuboxOTAUpload_setDisableBtns(true);

    const otapane = getYuboxPane('yuboxOTA', true);
    yuboxOTAUpload_setProgressBar(0);
    yuboxOTAUpload_fileProgress('-', '0', '0', '0');
    otapane.querySelectorAll('div.upload-progress').forEach((elem) => { elem.style.display = ''; });

    if (!!window.EventSource) {
        var sse = new EventSource(yuboxAPI('yuboxOTA')+'/events');
        sse.addEventListener('uploadFileStart', function (e) {
            var data = JSON.parse(e.data);
            var totalKB = data.total / 1024.0;
            var currUploadKB = data.currupload / 1024.0;
            yuboxOTAUpload_fileProgress(data.filename, 0, totalKB.toFixed(1), currUploadKB.toFixed(1));
            const pb = otapane.querySelector('div.progress-bar');
            pb.classList.remove('bg-info', 'bg-danger');
            pb.classList.add(data.firmware ? 'bg-danger' : 'bg-info');
            yuboxOTAUpload_setProgressBar(0);
        });
        sse.addEventListener('uploadFileProgress', function (e) {
            var data = JSON.parse(e.data);
            var totalKB = data.total / 1024.0;
            var currKB = data.current / 1024.0;
            var currUploadKB = data.currupload / 1024.0;
            yuboxOTAUpload_fileProgress(data.filename, currKB.toFixed(1), totalKB.toFixed(1), currUploadKB.toFixed(1));
            yuboxOTAUpload_setProgressBar(totalKB > 0.0 ? 100.0 * currKB / totalKB : 0);
        });
        sse.addEventListener('uploadFileEnd', function (e) {
            var data = JSON.parse(e.data);
            var totalKB = data.total / 1024.0;
            var currUploadKB = data.currupload / 1024.0;
            yuboxOTAUpload_fileProgress(data.filename, totalKB.toFixed(1), totalKB.toFixed(1), currUploadKB.toFixed(1));
            yuboxOTAUpload_setProgressBar(100);
        });
        sse.addEventListener('uploadPostTask', function (e) {
            var data = JSON.parse(e.data);
            var msg = data.task;
            var taskDesc = {
                'firmware-commit-start':        'Iniciando commit de firmware nuevo',
                'firmware-commit-failed':       'Falló el commit de firmware nuevo',
                'firmware-commit-end':          'Finalizado commit de firmware nuevo',
                'datafiles-load-oldmanifest':   'Cargando lista de archivos de datos viejos',
                'datafiles-delete-oldbackup':   'Borrando respaldo anterior de archivos de datos',
                'datafiles-rename-oldfiles':    'Respaldando archivos de datos viejos',
                'datafiles-rename-newfiles':    'Instalando archivos de datos nuevos',
                'datafiles-end':                'Fin de instalación de archivos de datos'
            };
            if (taskDesc[data.task] != undefined) msg = taskDesc[data.task];
            yuboxOTAUpload_setProgressBarMessage(100, msg);
        });
        otapane.data['sse'] = sse;
    } else {
      yuboxMostrarAlertText('danger', 'Este navegador no soporta Server-Sent Events, no se puede monitorear upload.');
    }
}

function yuboxOTAUpload_fileProgress(f, c, t, u)
{
    const otapane = getYuboxPane('yuboxOTA', true);
    otapane.querySelector('div.upload-progress span#filename').textContent = f;
    otapane.querySelector('div.upload-progress span#current').textContent = c;
    otapane.querySelector('div.upload-progress span#total').textContent = t;
    otapane.querySelector('div.upload-progress span#currupload').textContent = u;
}

function yuboxOTAUpload_shutdown()
{
    yuboxOTAUpload_setDisableBtns(false);
    const otapane = getYuboxPane('yuboxOTA', true);
    otapane.querySelectorAll('div.upload-progress').forEach((elem) => { elem.style.display = 'none'; });
    if (otapane.data['sse'] != null) {
        otapane.data['sse'].close();
        otapane.data['sse'] = null;
    }
}

function yuboxOTAUpload_setDisableBtns(v)
{
    getYuboxPane('yuboxOTA', true)
    .querySelectorAll('button[name=apply], button[name=rollback], button[name=reboot], select#yuboxfirmwarelist')
    .forEach((elem) => { elem.disabled = v; });
}

function yuboxOTAUpload_setProgressBar(v)
{
    yuboxOTAUpload_setProgressBarMessage(v, v.toFixed(1) + ' %');
}

function yuboxOTAUpload_setProgressBarMessage(v, msg)
{
    const otapane = getYuboxPane('yuboxOTA', true);
    const pb = otapane.querySelector('div.progress-bar');
    pb.style.width = v+'%';
    pb.attributes['aria-valuenow'] = v;
    pb.textContent = msg;
}


function yuboxAPI(s)
{
    var mockup =  window.location.pathname.startsWith('/yubox-mockup/');
    return mockup
        ? '/yubox-mockup/'+s+'.php'
        : '/yubox-api/'+s;
}

function yuboxMostrarAlertText(alertstyle, text, timeout)
{
    const content = document.createElement('span');
    content.textContent = text;
    return yuboxMostrarAlert(alertstyle, content, timeout);
}

function yuboxMostrarAlert(alertstyle, content, timeout)
{
    return yuboxDlgMostrarAlert('main > div.container', alertstyle, content, timeout);
}

function yuboxDlgMostrarAlertText(basesel, alertstyle, text, timeout)
{
    const content = document.createElement('span');
    content.textContent = text;
    return yuboxDlgMostrarAlert(basesel, alertstyle, content, timeout);
}

function yuboxDlgMostrarAlert(basesel, alertstyle, content, timeout)
{
    basesel = yuboxUnwrapJQ(basesel);
    if (typeof basesel == 'string') basesel = document.querySelector(basesel);

    // Buscar plantilla de mensaje alerta, clonar y preparar con estilo
    const tpl_al = basesel.querySelector('div.alert.yubox-alert-template');
    const al = tpl_al.cloneNode(true);
    al.classList.remove('yubox-alert-template');
    al.classList.add('yubox-alert');
    al.classList.add('alert-'+alertstyle);

    // Insertar contenido DOM que es texto del mensaje
    content = yuboxUnwrapJQ(content);
    al.querySelector('button.close').insertAdjacentElement('beforebegin', content);

    // Quitar cualquier alarma vieja, insertar la nueva
    const old_al = basesel.querySelector('div.yubox-alert');
    if (old_al != null && old_al.parentNode !== null) old_al.parentNode.removeChild(old_al);
    tpl_al.insertAdjacentElement('afterend', al);

    // Quitar mensaje de alarma luego de timeout
    if (timeout != undefined) {
        setTimeout(function() {
            if (al.parentNode !== null) al.parentNode.removeChild(al);
        }, timeout);
    }

    return yuboxWrapJQ(al);
}

function yuboxStdAjaxFailHandler(e, timeout)
{
    yuboxStdAjaxFailHandlerDlg('main > div.container', e, timeout);
}

function yuboxStdAjaxFailHandlerDlg(basesel, e, timeout)
{
    var msg;
    if (e.status == 0) {
        msg = 'Fallo al contactar dispositivo';
    } else if (e.responseJSON == undefined) {
        msg = 'Tipo de contenido inesperado en respuesta';
    } else {
        msg = e.responseJSON.msg;
    }
    yuboxDlgMostrarAlertText(basesel, 'danger', msg, timeout);
}

function getYuboxPane(modname, raw = false)
{
    let dom = document.querySelector('div#yuboxMainTabContent > div.tab-pane#'+modname);
    return raw ? dom : yuboxWrapJQ(dom);
}
function getYuboxNavTab(modname, raw = false)
{
    let dom = document.querySelector('ul#yuboxMainTab a#'+modname+'-tab[data-toggle="tab"]');
    return raw ? dom : yuboxWrapJQ(dom);
}

function yuboxFetch(module, rsrc = '', postData = null)
{
    let method = (postData == null) ? 'GET' : 'POST';
    return yuboxFetchMethod(method, module, rsrc, postData);
}

function yuboxFetchURL(url, postData = null)
{
    let method = (postData == null) ? 'GET' : 'POST';
    return yuboxFetchMethodURL(method, url, postData);
}

function yuboxFetchMethod(method, module, rsrc = '', postData = null)
{
    let url = yuboxAPI(module);
    if (rsrc != '') url += '/' + rsrc;

    return yuboxFetchMethodURL(method, url, postData);
}

function yuboxFetchMethodURL(method, url, postData = null)
{
    // Decidir Content-Type
    if (postData != null) {
        if (postData instanceof FormData) {
        } else if (postData instanceof URLSearchParams) {
        } else {
            // Se asume objeto ordinario
            postData = new URLSearchParams(postData);
        }
    }

    let init = {
        method: method
    };
    if (postData != null) init['body'] = postData;
    return fetch(url, init)
    .then(response => {
        let p;

        if (response.status == 204) {
            // Voy a asumir que realmente no hay más contenido
            p = Promise.resolve(null);
        } else {
            let ct = response.headers.get('content-type');
            if (ct.toLowerCase().indexOf('application/json') == 0)
                p = response.json();
            else if (ct.toLowerCase().indexOf('text/plain') == 0)
                p =  response.text();
            else if (ct.toLowerCase().indexOf('text/html') == 0)
                p = response.text(); // TODO: parseo?
            else
                p = response.blob(); // ¿Es esto lo más útil?
        }
        return p
        .then(data => {
            if (!response.ok) {
                let e = new Error(response.statusText, { cause: response });
                e.responseJSON = data;
                throw e;
            }
            return data;
        });
    });
}

// Las siguientes dos funciones envuelven un DOM pelado en jQuery, y lo extraen
// de un objeto jQuery, si jQuery está presente. De lo contrario, no hacen nada.
function yuboxWrapJQ(domobj)
{
    if (typeof jQuery == 'undefined') return domobj;
    return $(domobj);
}
function yuboxUnwrapJQ(jqobj)
{
    if (typeof jQuery == 'undefined') return jqobj;
    if (!(jqobj instanceof jQuery)) return jqobj;
    if (jqobj.length > 0) return jqobj[0];
    return null;
}